<template>
  <div class="chart-container">
    <h1 class="chart-title">商品价格渐缩漏斗图</h1>
    <el-form :model="form" label-width="100px" @submit.native.prevent>
        <el-row>
          <el-col :span="5">
            <el-form-item label="商品名称" prop="cm_name">
              <el-select v-model="form.cm_name" placeholder="请选择商品名称" clearable @change="updateUnitOptions">
                <el-option v-for="(item, index) in queryParams.cm_nameOptions" :key="index" :label="item" :value="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item label="价格单位" prop="unit">
              <el-select v-model="form.unit" placeholder="请选择单位价格" clearable @change="updateDateYearOptions">
                <el-option v-for="(item, index) in queryParams.unitOptions" :key="index" :label="item" :value="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item label="年份" prop="date_year">
              <el-select v-model="form.date_year" placeholder="请选择年份" clearable @change="updatePriceTypeOptions">
                <el-option v-for="(item, index) in queryParams.date_yearOptions" :key="index" :label="item" :value="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item label="价格类型" prop="price_type">
              <el-select v-model="form.price_type" placeholder="请选择价格类型">
                <el-option v-for="(item, index) in queryParams.price_typeOptions" :key="index" :label="item"
                  :value="item"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="4">
            <el-button type="primary" @click="handleQuery">查询</el-button>
          </el-col>
        </el-row>
      </el-form>
    <div class="chart" ref="chart"></div>
  </div>

</template>

<script>
  //调用echarts
  import echarts from "echarts";

  import {
    getCompare_prices,
    getAllprices
  } from "@/api/compare_prices/compare_prices";

  export default {
    name: "Compare_prices",
    data() {
      return {
        AllList: [], //下拉框的四个值
        queryParams: {
          cm_nameOptions: [],
          unitOptions: [],
          date_yearOptions: [],
          price_typeOptions: [],
        },
        form: {
          cm_name: '',
          unit: '',
          date_year: '',
          price_type: ''
        }
      }
    },
    created() {
      this.getList();
    },
    methods: {
      async handleQuery() {
        console.log(this.form.cm_name)

        getAllprices(this.form).then(response => {
          console.log(response.rows)
          var country = [];
          var price = [];
          var temp = response.rows
          for (var i = 0; i < temp.length; i++) {
            country.push(temp[i].name)
            var temp2 = {
              name: temp[i].name,
              value: temp[i].price
            }
            price.push(temp2);
          }
          console.log(country);
          console.log(price);

          this.drawchart(country, price);
        })

      },
      drawchart(d1, d2) {
        let that = this;
        console.log(that);
        console.log(that.$refs.chart);
        that.chart = echarts.init(that.$refs.chart);

        const option = {

          tooltip: {
            trigger: 'item',
            formatter: '{b}: {c}'
          },
          toolbox: {
            feature: {
              dataView: {
                readOnly: false
              },
              restore: {},
              saveAsImage: {}
            }
          },
          legend: {
            data: d1
          },
          series: [{
            name: 'Funnel',
            type: 'funnel',
            left: '10%',
            top: 60,
            bottom: 60,
            width: '80%',
            height: '80%',
            min: 0,
            max: d1.length,
            minSize: '0%',
            maxSize: '100%',
            sort: 'descending',
            gap: 2,
            label: {
              show: true,
              position: 'inside',
              formatter: '{b}' // 在漏斗图上显示数据
            },
            labelLine: {
              length: 10,
              lineStyle: {
                width: 1,
                type: 'solid'
              }
            },
            itemStyle: {
              borderColor: '#fff',
              borderWidth: 1
            },
            emphasis: {
              label: {
                fontSize: 20
              }
            },
            data: d2
          }]
        };
        this.chart.setOption(option);
      },
      updateUnitOptions() {
        const selectedCmName = this.form.cm_name;
        const filteredUnits = this.AllList
          .filter(item => item.cm_name === selectedCmName)
          .map(item => item.unit);
        this.queryParams.unitOptions = Array.from(new Set(filteredUnits));
        this.form.unit = ''; // 清空第二个下拉框的选择
        this.form.date_year = ''; // 清空第三个下拉框的选择
        this.form.price_type = ''; // 清空第四个下拉框的选择
      },
      updateDateYearOptions() {
        const selectedCmName = this.form.cm_name;
        const selectedUnit = this.form.unit;
        const filteredDateYears = this.AllList
          .filter(item => item.cm_name === selectedCmName && item.unit === selectedUnit)
          .map(item => item.date_year);
        this.queryParams.date_yearOptions = Array.from(new Set(filteredDateYears));
        this.form.date_year = ''; // 清空第三个下拉框的选择
        this.form.price_type = ''; // 清空第四个下拉框的选择
      },
      updatePriceTypeOptions() {
        const selectedCmName = this.form.cm_name;
        const selectedUnit = this.form.unit;
        const selectedDateYear = this.form.date_year;
        const filteredPriceTypes = this.AllList
          .filter(item => item.cm_name === selectedCmName && item.unit === selectedUnit && item.date_year ===
            selectedDateYear)
          .map(item => item.price_type);
        this.queryParams.price_typeOptions = Array.from(new Set(filteredPriceTypes));
        this.form.price_type = ''; // 清空第四个下拉框的选择
      },
      getList() {
        getCompare_prices().then(response => {
          console.log(response.rows);
          this.AllList = response.rows;

          this.AllList.forEach(item => {
            // 去重并存入cm_nameOptions
            this.queryParams.cm_nameOptions.push(item.cm_name);
            this.queryParams.cm_nameOptions = Array.from(new Set(this.queryParams.cm_nameOptions));

            // 去重并存入unitOptions
            this.queryParams.unitOptions.push(item.unit);
            this.queryParams.unitOptions = Array.from(new Set(this.queryParams.unitOptions));

            // 去重并存入date_yearOptions
            this.queryParams.date_yearOptions.push(item.date_year);
            this.queryParams.date_yearOptions = Array.from(new Set(this.queryParams.date_yearOptions));

            // 去重并存入price_typeOptions
            this.queryParams.price_typeOptions.push(item.price_type);
            this.queryParams.price_typeOptions = Array.from(new Set(this.queryParams.price_typeOptions));
          });
        })
      },
    }
  };
</script>

<style scoped>
  .chart-container {
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

  }

  .highcharts-pie-series .highcharts-point {
    stroke: #EDE;
    stroke-width: 2px;
  }

  .highcharts-pie-series .highcharts-data-label-connector {
    stroke: silver;
    stroke-dasharray: 2, 2;
    stroke-width: 2px;
  }

  .chart-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
  }

  .chart {
    flex: 1;
    width: 100%;
    height: 100%;
  }
</style>
