import request from '@/utils/request'

// 查询豆类信息列表
export function listBean(query) {
  return request({
    url: '/bean/bean/list',
    method: 'get',
    params: query
  })
}
