package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.Foodprice;
import com.ruoyi.apda.mapper.FoodpriceMapper;
import com.ruoyi.apda.service.IFoodpriceService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class FoodpriceServiceImpl extends ServiceImpl<FoodpriceMapper, Foodprice> implements IFoodpriceService {
    @Resource
    private FoodpriceMapper foodpriceMapper;
    @Override
    public List<Map<String, Object>> list_top10() {
        return foodpriceMapper.list_top10();
    }
    public List<Map<String, Object>> list_country() { return foodpriceMapper.list_country(); }

    public List<Map<String, Object>> list_commoditysource() { return foodpriceMapper.list_commoditysource(); }

}
