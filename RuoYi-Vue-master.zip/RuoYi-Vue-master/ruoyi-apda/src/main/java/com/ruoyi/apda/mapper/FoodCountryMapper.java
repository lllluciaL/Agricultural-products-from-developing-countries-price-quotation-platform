package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.FoodCountry;
import org.springframework.stereotype.Repository;

@Repository
public interface FoodCountryMapper extends BaseMapper<FoodCountry> {
}
