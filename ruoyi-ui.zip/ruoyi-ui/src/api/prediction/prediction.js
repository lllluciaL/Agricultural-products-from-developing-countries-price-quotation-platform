import request from '@/utils/request'

// 查询价格预测列表
export function listPrediction(query) {
  return request({
    url: '/prediction/prediction/list',
    method: 'get',
    params: query
  })
}