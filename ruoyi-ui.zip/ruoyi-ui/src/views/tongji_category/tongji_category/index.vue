<template>
  <div class="chart-container">
    <h1 class="chart-title">国家农产品分类占比</h1>
    <el-form :inline="true" ref="form" onsubmit="event.preventDefault()" :model="form" label-width="80px">
      <el-form-item label="国家" prop="suppid">
        <el-select v-model="form.name" placeholder="请选择国家">
          <el-option v-for="item in country" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
        <el-button round type="primary" icon="el-icon-search" size="medium"
          @click="getTongji_categoryList()">查询</el-button>
      </el-form-item>
    </el-form>
    <div class="chart" ref="chart"></div>
  </div>
</template>

<script>
  import echarts from 'echarts'
  import {
    getAllCategory,
    getAllCountry
  } from "@/api/tongji_category/tongji_category";
  import {
    Card,
    Row,
    Col,
    FormItem,
    Select
  } from 'element-ui';


  export default {
    components: {
      // 引入所需的组件
      'el-card': Card,
      'el-row': Row,
      'el-col': Col,
      'el-form-item': FormItem,
      'el-select': Select
    },
    data() {
      return {
        form: {
          name: ''
        },
        tongji_categoryData: [],
        country: [],
        name: ''
      };
    },
    mounted() {
      // 在组件挂载完成后，执行绘制图表的操作
      //this.drawChart();
      // this.getTongji_categoryList();
      this.getAllCountry();
    },
    methods: {
      getTongji_categoryList() {
        console.log(this.form.name)
        getAllCategory(this.form).then(response => {
          this.tongji_categoryData = response.rows;
          var typeTitle = [];
          var typeData = [];
          typeTitle = Object.keys(response.rows[0])
          var type = response.rows[0]
          var j = typeTitle.length
          var typeTitle2 = [];
          for (var i = 0; i < j; i++) {
            if (type[typeTitle[i]] != 0) {
              typeTitle2.push(typeTitle[i])
            }
          }
          console.log(typeTitle2)
          for (var i = 0; i < typeTitle2.length; i++) {
            //console.log(type[typeTitle[i]])
            var temp = {
              name: typeTitle2[i],
              value: type[typeTitle2[i]]
            }
            typeData.push(temp)
          }
          console.log(typeData)
          this.drawChart(typeTitle2, typeData)
        })
      },
      getAllCountry() {
        getAllCountry().then(response => {
          console.info(response.rows);
          this.country = response.rows;
        })
      },
      drawChart(d1, d2) {
        var chartDom = this.$refs.chart
        var myChart = echarts.init(chartDom)

        var option = {
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
          },
          legend: {
            orient: 'vertical',
            data: d1,
            left: 80,
            show: true, // 设置为false隐藏图例
            textStyle: {
              //图例字体大小
              fontSize: 20,
            },
          },
          series: [{
            name: 'Food Category',
            type: 'pie',
            radius: '55%', // 控制饼图的大小
            data: d2,
            emphasis: {
              itemStyle: {
                shadowBlur: 15,
                shadowOffsetX: 0,
                shadowColor: 'rgba(100,100,100,100)',
              }
            }
          }]
        }
        myChart.setOption(option)
      },


    }
  }
</script>


<style scoped>
  .chart-container {
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

  }
  .highcharts-pie-series .highcharts-point {
  	stroke: #EDE;
  	stroke-width: 2px;
  }
  .highcharts-pie-series .highcharts-data-label-connector {
  	stroke: silver;
  	stroke-dasharray: 2, 2;
  	stroke-width: 2px;
  }

  .chart-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
  }

  .chart {
    flex: 1;
    width: 100%;
    height: 100%;
  }
</style>
