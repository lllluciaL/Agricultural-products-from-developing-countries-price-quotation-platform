package com.ruoyi.apda.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Foodprice implements Serializable {
    private static final long serialVersionUID = 1L;

    /** 价格id */
    @TableId(type = IdType.AUTO)
    private Long wid;

    /** 国家名称 */
    @Excel(name = "国家名称")
    private String adm0Name;

    /** 国家id */
    private Long adm0Id;

    /** 州id */
    private Long adm1Id;

    /** 州名称 */
    @Excel(name = "州名称")
    private String adm1Name;

    /** 市场id */
    private Long mktId;

    /** 市场名称 */
    @Excel(name = "市场名称")
    private String mktName;

    /** 农产品id */
    private Long cmId;

    /** 农产品名称 */
    @Excel(name = "农产品名称")
    private String cmName;

    /** 价格类型id */
    private Long ptId;

    /** 价格类型名称 */
    @Excel(name = "价格类型名称")
    private String ptName;

    /** 数量单位id */
    private Long umId;

    /** 数量单位 */
    @Excel(name = "数量单位")
    private String umName;

    /** 价格 */
    @Excel(name = "价格")
    private Long mpPrice;

    /** 来源 */
    @Excel(name = "来源")
    private String mpCommoditysource;

    /** 时间 */
    @Excel(name = "时间")
    private String mpDate;

    /** 分类 */
    @Excel(name = "分类")
    private String category;

    /** 汇率 */
    @Excel(name = "汇率")
    private Double parities;

    /** 美元价格 */
    @Excel(name = "美元价格")
    private Double priceUsd;

    /** 删除标记 */
    @TableLogic
    private Long deleted;
}
