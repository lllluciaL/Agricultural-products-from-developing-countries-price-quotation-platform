package com.ruoyi.apda.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.apda.domain.AvgYear;

public interface IAvgYearService extends IService<AvgYear> {
}
