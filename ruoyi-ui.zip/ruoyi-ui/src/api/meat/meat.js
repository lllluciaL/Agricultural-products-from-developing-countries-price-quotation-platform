import request from '@/utils/request'

// 查询肉类信息列表
export function listMeat(query) {
  return request({
    url: '/meat/meat/list',
    method: 'get',
    params: query
  })
}