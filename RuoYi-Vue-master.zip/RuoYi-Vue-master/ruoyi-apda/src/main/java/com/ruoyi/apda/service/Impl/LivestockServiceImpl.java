package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.Livestock;
import com.ruoyi.apda.mapper.LivestockMapper;
import com.ruoyi.apda.service.ILivestockService;
import org.springframework.stereotype.Service;

@Service
public class LivestockServiceImpl extends ServiceImpl<LivestockMapper, Livestock> implements ILivestockService {
}
