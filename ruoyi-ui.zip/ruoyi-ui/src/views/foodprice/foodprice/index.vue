<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="100px">
      <el-form-item label="国家名称" prop="adm0Name">
        <el-input
          v-model="queryParams.adm0Name"
          placeholder="请输入国家名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>

      <el-form-item label="州名称" prop="adm1Name">
        <el-input
          v-model="queryParams.adm1Name"
          placeholder="请输入州名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>

      <el-form-item label="农产品名称" prop="cmName" >
        <el-input
          v-model="queryParams.cmName"
          placeholder="请输入农产品名称"
          clearable
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['foodprice:foodprice:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['foodprice:foodprice:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['foodprice:foodprice:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['foodprice:foodprice:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="foodpriceList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="国家名称" align="center" prop="adm0Name" />
      <el-table-column label="州名称" align="center" prop="adm1Name" />
      <el-table-column label="市场名称" align="center" prop="mktName" />
      <el-table-column label="农产品名称" align="center" prop="cmName" />
      <el-table-column label="价格类型名称" align="center" prop="ptName" />
      <el-table-column label="数量单位" align="center" prop="umName" />
      <el-table-column label="价格" align="center" prop="mpPrice" />
      <el-table-column label="来源" align="center" prop="mpCommoditysource" />
      <el-table-column label="时间" align="center" prop="mpDate" />
      <el-table-column label="分类" align="center" prop="category" />
      <el-table-column label="汇率" align="center" prop="parities" />
      <el-table-column label="美元价格" align="center" prop="priceUsd" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['foodprice:foodprice:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['foodprice:foodprice:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改农产品价格对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="国家名称" prop="adm0Name">
                  <el-input v-model="form.adm0Name" placeholder="请输入国家名称" />
                </el-form-item>
                <el-form-item label="国家id" prop="adm0Id">
                  <el-input v-model="form.adm0Id" placeholder="请输入国家id" />
                </el-form-item>
                <el-form-item label="州id" prop="adm1Id">
                  <el-input v-model="form.adm1Id" placeholder="请输入州id" />
                </el-form-item>
                <el-form-item label="州名称" prop="adm1Name">
                  <el-input v-model="form.adm1Name" placeholder="请输入州名称" />
                </el-form-item>
                <el-form-item label="市场id" prop="mktId">
                  <el-input v-model="form.mktId" placeholder="请输入市场id" />
                </el-form-item>
                <el-form-item label="市场名称" prop="mktName">
                  <el-input v-model="form.mktName" placeholder="请输入市场名称" />
                </el-form-item>
                <el-form-item label="农产品id" prop="cmId">
                  <el-input v-model="form.cmId" placeholder="请输入农产品id" />
                </el-form-item>
                <el-form-item label="农产品名称" prop="cmName">
                  <el-input v-model="form.cmName" placeholder="请输入农产品名称" />
                </el-form-item>
                <el-form-item label="价格类型id" prop="ptId">
                  <el-input v-model="form.ptId" placeholder="请输入价格类型id" />
                </el-form-item>
                <el-form-item label="价格类型名称" prop="ptName">
                  <el-input v-model="form.ptName" placeholder="请输入价格类型名称" />
                </el-form-item>
                <el-form-item label="数量单位id" prop="umId">
                  <el-input v-model="form.umId" placeholder="请输入数量单位id" />
                </el-form-item>
                <el-form-item label="数量单位" prop="umName">
                  <el-input v-model="form.umName" placeholder="请输入数量单位" />
                </el-form-item>
                <el-form-item label="价格" prop="mpPrice">
                  <el-input v-model="form.mpPrice" placeholder="请输入价格" />
                </el-form-item>
                <el-form-item label="来源" prop="mpCommoditysource">
                  <el-input v-model="form.mpCommoditysource" placeholder="请输入来源" />
                </el-form-item>
                <el-form-item label="时间" prop="mpDate">
                  <el-input v-model="form.mpDate" placeholder="请输入时间" />
                </el-form-item>
                <el-form-item label="分类" prop="category">
                  <el-input v-model="form.category" placeholder="请输入分类" />
                </el-form-item>
                <el-form-item label="汇率" prop="parities">
                  <el-input v-model="form.parities" placeholder="请输入汇率" />
                </el-form-item>
                <el-form-item label="美元价格" prop="priceUsd">
                  <el-input v-model="form.priceUsd" placeholder="请输入美元价格" />
                </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listFoodprice, getFoodprice, delFoodprice, addFoodprice, updateFoodprice } from "@/api/foodprice/foodprice";

export default {
  name: "Foodprice",
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 农产品价格表格数据
      foodpriceList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        adm0Name: null,
        adm0Id: null,
        adm1Id: null,
        adm1Name: null,
        mktId: null,
        mktName: null,
        cmId: null,
        cmName: null,
        ptId: null,
        ptName: null,
        umId: null,
        umName: null,
        mpPrice: null,
        mpCommoditysource: null,
        mpDate: null,
        category: null,
        parities: null,
        priceUsd: null,
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        adm0Name: [
          { required: true, message: "国家名称不能为空", trigger: "blur" }
        ],
        adm1Id: [
          { required: true, message: "州id不能为空", trigger: "blur" }
        ],
        mktId: [
          { required: true, message: "市场id不能为空", trigger: "blur" }
        ],
        cmId: [
          { required: true, message: "农产品id不能为空", trigger: "blur" }
        ],
        umId: [
          { required: true, message: "数量单位id不能为空", trigger: "blur" }
        ],
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询农产品价格列表 */
    getList() {
      this.loading = true;
      listFoodprice(this.queryParams).then(response => {
        this.foodpriceList = response.rows;
        this.total = response.total;
        this.loading = false;
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        wid: null,
        adm0Name: null,
        adm0Id: null,
        adm1Id: null,
        adm1Name: null,
        mktId: null,
        mktName: null,
        cmId: null,
        cmName: null,
        ptId: null,
        ptName: null,
        umId: null,
        umName: null,
        mpPrice: null,
        mpCommoditysource: null,
        mpDate: null,
        category: null,
        parities: null,
        priceUsd: null,
        deleted: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map(item => item.wid)
      this.single = selection.length!==1
      this.multiple = !selection.length
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加农产品价格";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const wid = row.wid || this.ids
      getFoodprice(wid).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改农产品价格";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.wid != null) {
            updateFoodprice(this.form).then(response => {
              this.$modal.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addFoodprice(this.form).then(response => {
              this.$modal.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const wids = row.wid || this.ids;
      this.$modal.confirm('是否确认删除农产品价格编号为"' + wids + '"的数据项？').then(function() {
        return delFoodprice(wids);
      }).then(() => {
        this.getList();
        this.$modal.msgSuccess("删除成功");
      }).catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download('foodprice/foodprice/export', {
        ...this.queryParams
      }, `foodprice_${new Date().getTime()}.xlsx`)
    }
  }
};
</script>
