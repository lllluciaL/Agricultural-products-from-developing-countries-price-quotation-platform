package com.ruoyi.apda.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.apda.domain.MktTab;

import java.util.List;
import java.util.Map;

public interface IMktTabService extends IService<MktTab> {
    List<Map<String,Object>> getAllname();

    List<Map<String, Object>> ListByPrice(com.ruoyi.apda.form.Market market);
}
