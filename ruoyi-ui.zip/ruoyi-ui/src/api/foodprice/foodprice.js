import request from '@/utils/request'

// 查询农产品价格列表
export function listFoodprice(query) {
  return request({
    url: '/foodprice/foodprice/list',
    method: 'get',
    params: query
  })
}

// 查询农产品价格详细
export function getFoodprice(wid) {
  return request({
    url: '/foodprice/foodprice/' + wid,
    method: 'get'
  })
}

// 新增农产品价格
export function addFoodprice(data) {
  return request({
    url: '/foodprice/foodprice',
    method: 'post',
    data: data
  })
}

// 修改农产品价格
export function updateFoodprice(data) {
  return request({
    url: '/foodprice/foodprice',
    method: 'put',
    data: data
  })
}

// 删除农产品价格
export function delFoodprice(wid) {
  return request({
    url: '/foodprice/foodprice/' + wid,
    method: 'delete'
  })
}
