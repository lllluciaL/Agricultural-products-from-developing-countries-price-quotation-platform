package com.ruoyi.apda.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Prediction {
    private static final long serialVersionUID = 1L;

    /** id */
    @TableId(type = IdType.AUTO)
    private Long pid;

    /** 国家名称 */
    @Excel(name = "国家名称")
    private String adm0Name;

    /** 城市名称 */
    @Excel(name = "城市名称")
    private String adm1Name;

    /** 商品名称 */
    @Excel(name = "商品名称")
    private String cmName;

    /** 价格类型 */
    @Excel(name = "价格类型")
    private String ptName;

    /** 商品数量单位 */
    @Excel(name = "商品数量单位")
    private String umName;

    /** 2015年价格 */
    @Excel(name = "2015年价格")
    private float price2015;

    /** 2016年价格 */
    @Excel(name = "2016年价格")
    private float price2016;

    /** 2017年价格 */
    @Excel(name = "2017年价格")
    private float price2017;

    /** 预测价格 */
    @Excel(name = "预测价格")
    private float pricePredict;
}
