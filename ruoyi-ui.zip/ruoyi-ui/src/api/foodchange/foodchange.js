// import request from '@/utils/request'
// // 查询价格变化趋势详细
// export function getAllChange() {
//   return request({
//     url: '/change/change/getAllChange',
//     method: 'get'
//   })
// }
import request from '@/utils/request'

// 查询价格变化趋势列表
export function listFoodchange(query) {
  return request({
    url: '/foodchange/foodchange/list',
    method: 'get',
    params: query
  })
}



