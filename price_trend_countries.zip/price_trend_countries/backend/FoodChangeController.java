package com.ruoyi.apda.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ruoyi.apda.domain.FoodChange;
import com.ruoyi.apda.domain.Store;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ruoyi.common.core.controller.BaseController;

import com.ruoyi.apda.service.IFoodChangeService;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 价格变化趋势Controller
 *
 * @author zyn
 * @date 2023-07-04
 */
@RestController
@RequestMapping("/foodchange/foodchange")
public class FoodChangeController extends BaseController
{
    @Autowired
    private IFoodChangeService foodChangeService;

    /**
     * 查询价格变化趋势列表
     */
    @PreAuthorize("@ss.hasPermi('foodchange:foodchange:list')")
    @GetMapping("/list")
    public TableDataInfo list(FoodChange change)
    {
        QueryWrapper<FoodChange> queryWrapper=new QueryWrapper<>();
        if(change.getAdm0Name()!=null&&!"".equals(change.getAdm0Name())){
            queryWrapper.eq("adm0_name",change.getAdm0Name());
        }
        if(change.getCmName()!=null&&!"".equals(change.getCmName())){
            queryWrapper.eq("cm_name",change.getCmName());
        }
        startPage();
        List<FoodChange> list = foodChangeService.list(queryWrapper);

        return getDataTable(list);
    }


}
