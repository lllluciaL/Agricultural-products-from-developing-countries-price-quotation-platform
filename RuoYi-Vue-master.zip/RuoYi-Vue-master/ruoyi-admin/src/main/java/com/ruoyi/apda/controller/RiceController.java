package com.ruoyi.apda.controller;

import java.util.List;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ruoyi.common.core.controller.BaseController;

import com.ruoyi.apda.domain.Rice;
import com.ruoyi.apda.service.IRiceService;

import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 米类信息Controller
 *
 * @author zyn
 * @date 2023-07-08
 */
@RestController
@RequestMapping("/rice/rice")
public class RiceController extends BaseController
{
    @Autowired
    private IRiceService riceService;

    /**
     * 查询米类信息列表
     */
    @PreAuthorize("@ss.hasPermi('rice:rice:list')")
    @GetMapping("/list")
    public TableDataInfo list(Rice rice)
    {
        QueryWrapper<Rice> queryWrapper=new QueryWrapper<>();
        if(rice.getPricetype()!=null&&!"".equals(rice.getPricetype())){
            queryWrapper.like("pricetype",rice.getPricetype());
        }
        if(rice.getPriceunit()!=null&&!"".equals(rice.getPriceunit())){
            queryWrapper.eq("priceunit",rice.getPriceunit());
        }
        startPage();
        List<Rice> list = riceService.list(queryWrapper);
        return getDataTable(list);
    }

}
