package com.ruoyi.apda.controller;

import com.ruoyi.apda.service.IFoodpriceService;
import com.ruoyi.common.core.domain.AjaxResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/echarts")
@CrossOrigin
public class EchartsController {
    @Autowired
    IFoodpriceService foodpriceService;
    @PreAuthorize("@ss.hasPermi('echarts:countries')")
    @GetMapping("/countries")
    public AjaxResult countries(){
        System.out.println(foodpriceService.list_top10());
        return AjaxResult.success(foodpriceService.list_top10());
    }
    @PreAuthorize("@ss.hasPermi('echarts:goods')")
    @GetMapping("/goods")
    public AjaxResult goods(){
        System.out.println(foodpriceService.list_country());
        return AjaxResult.success(foodpriceService.list_country());
    }
    @PreAuthorize("@ss.hasPermi('echarts:commoditysource')")
    @GetMapping("/commoditysource")
    public AjaxResult commoditysource(){
        System.out.println(foodpriceService.list_commoditysource());
        return AjaxResult.success(foodpriceService.list_commoditysource());
    }
}
