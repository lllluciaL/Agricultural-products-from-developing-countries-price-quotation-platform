package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.Tongji_category;
import com.ruoyi.apda.form.Name;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface Tongji_categoryMapper extends BaseMapper<Tongji_category> {

    List<Map<String, Object>> listByName(Name name);

    List<Map<String, Object>> getAllCountry();
}
