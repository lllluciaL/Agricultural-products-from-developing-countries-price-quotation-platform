package com.ruoyi.apda.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.apda.domain.Tongji_category;
import com.ruoyi.apda.form.Name;

import java.util.List;
import java.util.Map;

public interface Tongji_categoryService extends IService<Tongji_category> {

    List<Map<String, Object>> ListByName(Name name);

    List<Map<String,Object>> getAllCountry();
}
