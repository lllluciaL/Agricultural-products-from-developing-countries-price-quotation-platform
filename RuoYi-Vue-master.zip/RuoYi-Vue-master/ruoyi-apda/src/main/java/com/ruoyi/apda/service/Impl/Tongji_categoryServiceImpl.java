package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.Tongji_category;
import com.ruoyi.apda.form.Name;
import com.ruoyi.apda.mapper.Tongji_categoryMapper;
import com.ruoyi.apda.service.Tongji_categoryService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class Tongji_categoryServiceImpl extends ServiceImpl<Tongji_categoryMapper,Tongji_category> implements  Tongji_categoryService{


    @Resource Tongji_categoryMapper tongji_categoryMapper;

    @Override
    public List<Map<String, Object>> ListByName(Name name) {
        return tongji_categoryMapper.listByName(name);
    }

    @Override
    public List<Map<String, Object>> getAllCountry() {
        return tongji_categoryMapper.getAllCountry();
    }
}



