package com.ruoyi.apda.controller;

import com.ruoyi.apda.domain.ComparePrices;
import com.ruoyi.apda.form.Name;
import com.ruoyi.apda.form.Price;
import com.ruoyi.apda.service.IComparePricesService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/compare_prices/compare_prices")
@CrossOrigin
public class ComparePricesController extends BaseController {
    @Autowired
    private IComparePricesService comparePricesService;

    @PreAuthorize("@ss.hasPermi('compare_prices:compare_prices:getCompare_prices')")
    @PostMapping("/getCompare_prices")
    public TableDataInfo getCompare_prices(){
        return getDataTable(comparePricesService.getCompare_prices());
    }



    @PreAuthorize("@ss.hasPermi('compare_prices:compare_prices:getAllprices')")
    @PostMapping("/getAllprices")
    public TableDataInfo getAllprices(@RequestBody Price price){
        System.out.println(price.getCm_name());
        List<Map<String,Object>> list=comparePricesService.ListByPrice(price);
        System.out.println(list);
        return getDataTable(list);
    }

}
