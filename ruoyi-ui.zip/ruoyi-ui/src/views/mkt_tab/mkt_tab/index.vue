<template>
  <div class="chart-container">
    <h1 class="chart-title">市场价格分布</h1>
    <el-form :model="form" label-width="100px" @submit.native.prevent>
      <el-row>
        <el-col :span="5">
          <el-form-item label="国家名称" prop="cm_name">
            <el-select v-model="form.adm0_name" placeholder="请选择国家名称" clearable @change="updatecm_nameOptions">
              <el-option v-for="(item, index) in queryParams.adm0_nameOptions" :key="index" :label="item"
                :value="item"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="5">
          <el-form-item label="商品名称" prop="unit">
            <el-select v-model="form.cm_name" placeholder="请选择商品名称" clearable @change="updateunitOptions">
              <el-option v-for="(item, index) in queryParams.cm_nameOptions" :key="index" :label="item"
                :value="item"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="5">
          <el-form-item label="单位名称" prop="date_year">
            <el-select v-model="form.unit" placeholder="请选择单位名称" clearable @change="updatePriceTypeOptions">
              <el-option v-for="(item, index) in queryParams.unitOptions" :key="index" :label="item"
                :value="item"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="5">
          <el-form-item label="价格类型" prop="price_type">
            <el-select v-model="form.price_type" placeholder="请选择价格类型">
              <el-option v-for="(item, index) in queryParams.price_typeOptions" :key="index" :label="item"
                :value="item"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-button type="primary" @click="handleQuery">查询</el-button>
        </el-col>
      </el-row>
    </el-form>
    <div class="chart" ref="chart"></div>
    <div id="main" style="width:auto; height:400px;"></div>
  </div>

</template>

<script>
  import echarts from "echarts";
  import 'echarts-gl';
  import {
    getAllname,
    getAllprices
  } from "@/api/mkt_tab/mkt_tab";

  export default {
    name: "Mkt_tab",
    data() {
      return {
        AllList: [], //下拉框的四个值
        queryParams: {
          adm0_nameOptions: [],
          cm_nameOptions: [],
          unitOptions: [],
          price_typeOptions: [],
        },
        form: {
          adm0_name: '',
          cm_name: '',
          unit: '',
          price_type: ''
        }
      };
    },
    created() {
      this.getList();
    },
    methods: {
      async handleQuery() {
        //console.log(this.form.cm_name)
        var data = [];
        getAllprices(this.form).then(response => {
          var temp = response.data;
          console.log(response);
          data.push(["name", "date_year","price"]);
          temp.forEach(function(item, index) {
            data.push([item.name, item.date_year,item.price]);
          });
          data.sort(function(a, b) {//data按时间排序
              if (a[1] < b[1]) {
                return -1;
              } else if (a[1] > b[1]) {
                return 1;
              } else {
                return 0;
              }
            });
          console.log(data);
          var chartContainer = document.getElementById('main');
          chartContainer.style.width = '800px';
          chartContainer.style.height = '600px';
          var myChart = echarts.init(chartContainer);
          console.log(myChart);
          var symbolSize = 2.5;
          var option = {
             tooltip: { },            
            series: [{
              type: 'scatter3D',
              data: data, // 数据
              symbolSize: 10,
              itemStyle: {
                opacity: 0.8
              }
            }],
            xAxis3D: {
              type: 'category',
              scale: true
            },
            yAxis3D: {
              type: 'category',
              scale: true
            },
            zAxis3D: {
              type: 'value',
              scale: true
            },
            grid3D: {
              viewControl: {
                alpha: 45,
                beta: 30
              }
            }
          };
          myChart.setOption(option);
        });
      },
      updatecm_nameOptions() {
        const selectedCmName = this.form.adm0_name;
        console.log(this.form.adm0_name);
        const filteredUnits = this.AllList
          .filter(item => item.adm0_name === selectedCmName)
          .map(item => item.cm_name);
        this.queryParams.cm_nameOptions = Array.from(new Set(filteredUnits));
        this.form.cm_name = ''; // 清空第二个下拉框的选择
        this.form.unit = ''; // 清空第三个下拉框的选择
        this.form.price_type = ''; // 清空第四个下拉框的选择
      },
      updateunitOptions() {
        const selectedCmName = this.form.adm0_name;
        const selectedUnit = this.form.cm_name;
        const filteredDateYears = this.AllList
          .filter(item => item.adm0_name === selectedCmName && item.cm_name === selectedUnit)
          .map(item => item.unit);
        this.queryParams.unitOptions = Array.from(new Set(filteredDateYears));
        this.form.unit = ''; // 清空第三个下拉框的选择
        this.form.price_type = ''; // 清空第四个下拉框的选择
      },
      updatePriceTypeOptions() {
        const selectedCmName = this.form.adm0_name;
        const selectedUnit = this.form.cm_name;
        const selectedDateYear = this.form.unit;
        const filteredPriceTypes = this.AllList
          .filter(item => item.adm0_name === selectedCmName && item.cm_name === selectedUnit && item.unit ===
            selectedDateYear)
          .map(item => item.price_type);
        this.queryParams.price_typeOptions = Array.from(new Set(filteredPriceTypes));
        this.form.price_type = ''; // 清空第四个下拉框的选择
      },
      getList() {
        getAllname().then(response => {
          //console.log(response.rows);
          this.AllList = response.rows;

          this.AllList.forEach(item => {
            // 去重并存入adm0_nameOptions
            this.queryParams.adm0_nameOptions.push(item.adm0_name);
            this.queryParams.adm0_nameOptions = Array.from(new Set(this.queryParams.adm0_nameOptions));

            // 去重并存入cm_nameOptions
            this.queryParams.cm_nameOptions.push(item.cm_name);
            this.queryParams.cm_nameOptions = Array.from(new Set(this.queryParams.cm_nameOptions));

            // 去重并存入unitOptions
            this.queryParams.unitOptions.push(item.unit);
            this.queryParams.unitOptions = Array.from(new Set(this.queryParams.unitOptions));

            // 去重并存入price_typeOptions
            this.queryParams.price_typeOptions.push(item.price_type);
            this.queryParams.price_typeOptions = Array.from(new Set(this.queryParams.price_typeOptions));
          });
        })
      },

    }
  };
</script>


<style scoped>
  .chart-container {
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

  }

  .highcharts-pie-series .highcharts-point {
    stroke: #EDE;
    stroke-width: 2px;
  }

  .highcharts-pie-series .highcharts-data-label-connector {
    stroke: silver;
    stroke-dasharray: 2, 2;
    stroke-width: 2px;
  }

  .chart-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
  }

  .chart {
    flex: 1;
    width: 100%;
    height: 100%;
  }
</style>
