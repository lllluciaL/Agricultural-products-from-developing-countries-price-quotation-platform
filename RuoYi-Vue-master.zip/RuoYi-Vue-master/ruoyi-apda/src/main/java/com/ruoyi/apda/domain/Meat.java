package com.ruoyi.apda.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Meat {
    private static final long serialVersionUID = 1L;

    /** id */
    @TableId(type = IdType.AUTO)
    private Long mid;

    /** 肉类名称 */
    @Excel(name = "肉类名称")
    private String mname;

    /** 国家个数 */
    @Excel(name = "国家个数")
    private Long countrysum;

    /** 价格 */
    @Excel(name = "价格")
    private float price;

    /** 单位 */
    @Excel(name = "单位")
    private String priceunit;

    /** 价格类型 */
    @Excel(name = "价格类型")
    private String pricetype;
}
