package com.ruoyi.apda.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ruoyi.apda.domain.Foodprice;
import com.ruoyi.apda.service.IFoodpriceService;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

    /**
     * 农产品价格Controller
     *
     * @author ruoyi
     * @date 2023-07-04
     */
    @RestController
    @RequestMapping("/foodprice/foodprice")
    public class FoodpriceController extends BaseController
    {
        @Autowired
        private IFoodpriceService foodpriceService;

        /**
         * 查询农产品价格列表
         */
        @PreAuthorize("@ss.hasPermi('foodprice:foodprice:list')")
        @GetMapping("/list")
        public TableDataInfo list(Foodprice foodprices)
        {
            QueryWrapper<Foodprice> queryWrapper = new QueryWrapper<>();
            if(foodprices.getCmName()!=null&&!"".equals(foodprices.getCmName())){
                queryWrapper.like("cm_name",foodprices.getCmName());
            }
            if(foodprices.getAdm0Name()!=null&&!"".equals(foodprices.getAdm0Name())){
                queryWrapper.like("adm0_name",foodprices.getAdm0Name());
            }
            if(foodprices.getAdm1Name()!=null&&!"".equals(foodprices.getAdm1Name())){
                queryWrapper.like("adm1_name",foodprices.getAdm1Name());
            }
            if(foodprices.getMpDate()!=null&&!"".equals(foodprices.getMpDate())){
                queryWrapper.like("mp_date",foodprices.getMpDate());
            }
            startPage();
            List<Foodprice> list = foodpriceService.list(queryWrapper);
            return getDataTable(list);
        }

        /**
         * 导出农产品价格列表
         */
        @PreAuthorize("@ss.hasPermi('foodprice:foodprice:export')")
        @Log(title = "农产品价格", businessType = BusinessType.EXPORT)
        @PostMapping("/export")
        public void export(HttpServletResponse response, Foodprice foodprices)
        {
            QueryWrapper<Foodprice> queryWrapper = new QueryWrapper<>();
            if(foodprices.getCmName()!=null&&!"".equals(foodprices.getCmName())){
                queryWrapper.like("cm_name",foodprices.getCmName());
            }
            if(foodprices.getAdm0Name()!=null&&!"".equals(foodprices.getAdm0Name())){
                queryWrapper.like("adm0_name",foodprices.getAdm0Name());
            }
            if(foodprices.getAdm1Name()!=null&&!"".equals(foodprices.getAdm1Name())){
                queryWrapper.like("adm1_name",foodprices.getAdm1Name());
            }
            if(foodprices.getMpDate()!=null&&!"".equals(foodprices.getMpDate())){
                queryWrapper.like("mp_date",foodprices.getMpDate());
            }
            List<Foodprice> list = foodpriceService.list(queryWrapper);
            ExcelUtil<Foodprice> util = new ExcelUtil<Foodprice>(Foodprice.class);
            util.exportExcel(response, list, "农产品价格数据");
        }

        /**
         * 获取农产品价格详细信息
         */
        @PreAuthorize("@ss.hasPermi('foodprice:foodprice:query')")
        @GetMapping(value = "/{wid}")
        public AjaxResult getInfo(@PathVariable("wid") Long wid)
        {
            return success(foodpriceService.getById(wid));
        }

        /**
         * 新增农产品价格
         */
        @PreAuthorize("@ss.hasPermi('foodprice:foodprice:add')")
        @Log(title = "农产品价格", businessType = BusinessType.INSERT)
        @PostMapping
        public AjaxResult add(@RequestBody Foodprice foodprice)
        {
            return toAjax(foodpriceService.save(foodprice));
        }

        /**
         * 修改农产品价格
         */
        @PreAuthorize("@ss.hasPermi('foodprice:foodprice:edit')")
        @Log(title = "农产品价格", businessType = BusinessType.UPDATE)
        @PutMapping
        public AjaxResult edit(@RequestBody Foodprice foodprice)
        {
            return toAjax(foodpriceService.updateById(foodprice));
        }

        /**
         * 删除农产品价格
         */
        @PreAuthorize("@ss.hasPermi('foodprice:foodprice:remove')")
        @Log(title = "农产品价格", businessType = BusinessType.DELETE)
        @DeleteMapping("/{wids}")
        public AjaxResult remove(@PathVariable List<Long> wids)
        {
            return toAjax(foodpriceService.removeByIds(wids));
        }
    }
