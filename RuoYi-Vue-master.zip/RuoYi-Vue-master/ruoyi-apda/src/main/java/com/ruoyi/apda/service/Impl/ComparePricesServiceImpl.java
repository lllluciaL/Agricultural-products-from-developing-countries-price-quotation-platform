package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.ComparePrices;
import com.ruoyi.apda.form.Price;
import com.ruoyi.apda.mapper.ComparePricesMapper;
import com.ruoyi.apda.service.IComparePricesService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class ComparePricesServiceImpl extends ServiceImpl<ComparePricesMapper, ComparePrices> implements IComparePricesService {
   @Resource ComparePricesMapper comparePricesMapper;

    @Override
    public List<Map<String, Object>> getCompare_prices() {
        return comparePricesMapper.getCompare_prices();
    }

    @Override
    public List<Map<String, Object>> ListByPrice(Price price) {
        return comparePricesMapper.ListByPrice(price);
    }
}
