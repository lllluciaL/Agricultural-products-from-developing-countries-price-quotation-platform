<template>
  <el-card>
    <div id="countries" style="width:auto; height:400px;"></div>
    <div id="goods" style="width:auto; height:600px;"></div>
    <div id="commoditysource" style="width:auto; height:550px;"></div>
  </el-card>
</template>

<script>
  import * as echarts from 'echarts';
  import request from "@/utils/request";
  import array from "@/utils/request"
  export default {
    name: 'index',
    data() {
      return {
        chartOptions: {
          xAxis: {
            type: 'category',
            data: [],
          },
          yAxis: {
            type: 'value',
          },
          series: [{
            type: 'bar',
            data: [],
          }],
        },
      };
    },
    methods: {
      showCountries() {
        var chartDom = document.getElementById('countries');
        var Chart = echarts.init(chartDom);
        var countriesoption;

        countriesoption = {
          title: {
            text: '热们商品top 10',
            left: 'center'
          },
          tooltip: {
            trigger: 'axis'
          },
          legend: {
            orient: 'vertical',
            left: 'left',
            top: 'middle'
          },
          xAxis: {
            type: 'category',
            data: [], // 数据的x轴坐标数组
            axisLabel: {
              interval: 0, // 设置为 0 表示显示所有标签
            },
          },
          yAxis: {
            type: 'value'
          },
          grid: {
            left: '10%',
            right: '10%',
            bottom: '10%',
            containLabel: true
          },
          series: [{
            barWidth: 40, // 设置直方图的宽度
            barGap: '20%',
            type: 'bar',
            data: [],
            label: {
              show: true,
              position: 'top'
            }
          }]
        };

        request.get("/echarts/countries").then(res => {
          const data = res.data;
          let xData = []; // x轴坐标数组
          let yData = []; // y轴数据数组

          data.forEach(item => {
            xData.push(item.cm_name);
            yData.push(item.count);
          });

          // 对yData进行排序
          let sortedData = yData.slice().sort((a, b) => b - a); // 复制yData数组并进行排序
          // 取Top 10 的数据
          let top10Data = sortedData.slice(0, 10);
          let top10Index = top10Data.map((value) => yData.indexOf(value)); // 取出排名前十数据在yData数组中的索引
          let top10XData = top10Index.map((index) => xData[index]);
          countriesoption.xAxis.data = top10XData;
          countriesoption.series[0].data = top10Data;
          Chart.setOption(countriesoption);
        });
      },
      showGoods() {
        var chartDom = document.getElementById('goods');
        var Chart = echarts.init(chartDom);
        var goodsoption;

        goodsoption = {
          title: {
            text: '国家经济规模',
            left: 'center',
          },

          tooltip: {
            trigger: 'item',
            formatter: '{b}: {c} ({d}%)'
          },

          legend: {
            orient: 'vertical',
            left: 'top',
            top: 'middle',
          },
          series: [{
            type: 'pie',
            data: [],
            label: {
              show: true,
              position: 'outside',
              formatter: '{b}'
            }
          }],
        };

        request.get("/echarts/goods").then(res => {
          const data = res.data;
          var pieData = [];
          var otherCount = 0;
          var totalCount = 0;

          // 计算总数
          data.forEach(item => {
            totalCount += item.count;
          });

          // 遍历数据，判断是否满足归为 "other" 类别的条件
          data.forEach(item => {
            // 计算当前项的百分比
            var percentage = item.count / totalCount;

            if (percentage >= 0.01) {
              // 添加到饼图数据中
              pieData.push({
                name: item.adm0_name,
                value: item.count
              });
            } else {
              // 归为 "other" 类别
              otherCount += item.count;
            }
          });

          // 添加 "other" 类别到饼图数据中
          if (otherCount > 0) {
            pieData.push({
              name: "Others",
              value: otherCount
            });
          }

          // 更新饼图数据
          goodsoption.series[0].data = pieData;

          // 应用更新后的配置选项到图表中
          Chart.setOption(goodsoption);
        });
      },
      showCommoditysource() {
        var chartDom = document.getElementById('commoditysource');
        var Chart = echarts.init(chartDom);
        var commoditysourceoption;

        commoditysourceoption = {
          title: {
            text: '商品来源统计',
            left: 'center'
          },
          tooltip: {
            trigger: 'item',
            formatter: '{b}: {c} ({d}%)'
          },

          legend: {
            orient: 'vertical',
            left: 'top',
            top: 'middle',
          },
          series: [{
            type: 'pie',
            data: [],
            label: {
              show: true,
              position: 'outside',
              formatter: '{b}'
            }
          }],
        };

        request.get("/echarts/commoditysource").then(res => {
          const data = res.data;
          var pieData = [];
          var otherCount = 0;
          var totalCount = 0;

          // 计算总数
          data.forEach(item => {
            totalCount += item.count;
          });

          // 遍历数据，判断是否满足归为 "other" 类别的条件
          data.forEach(item => {
            // 计算当前项的百分比
            var percentage = item.count / totalCount;

            if (percentage >= 0.01) {
              // 添加到饼图数据中
              pieData.push({
                name: item.mp_commoditysource,
                value: item.count
              });
            } else {
              // 归为 "other" 类别
              otherCount += item.count;
            }
          });

          // 添加 "other" 类别到饼图数据中
          if (otherCount > 0) {
            pieData.push({
              name: "Others",
              value: otherCount
            });
          }

          // 更新饼图数据
          commoditysourceoption.series[0].data = pieData;

          // 应用更新后的配置选项到图表中
          Chart.setOption(commoditysourceoption);
        });
      }
    },

    mounted() {
      this.showCountries()
      this.showGoods()
      this.showCommoditysource()
    },
  }
</script>

<style>
  .el-row {
    padding: 3px;
  }

  .el-col {
    padding: 4px;
  }
</style>
