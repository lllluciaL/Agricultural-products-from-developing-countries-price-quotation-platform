package com.ruoyi.apda.controller;


import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.apda.domain.FoodCountry;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;

import com.ruoyi.apda.service.IFoodCountryService;


/**
 * 国家概览Controller
 *
 * @author zyn
 * @date 2023-07-03
 */
@RestController
@RequestMapping("/country/country")
public class FoodCountryController extends BaseController {
    @Autowired
    private IFoodCountryService foodCountryService;


//    /**
//     * 获取国家概览详细信息
//     */
//    @PreAuthorize("@ss.hasPermi('country:country:query')")
//    @GetMapping(value = "/{aid}")
//    public AjaxResult getInfo(@PathVariable("aid") Long aid) {
//        return success(foodCountryService.getById(aid));
//    }
    /**
     * 查询所有国家
     */
    @PreAuthorize("@ss.hasPermi('country:country:getAllCountry')")
    @GetMapping("/getAllCountry")
    public TableDataInfo getAllParities(){
        return getDataTable(foodCountryService.list());
    }



}