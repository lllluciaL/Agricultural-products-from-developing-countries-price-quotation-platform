import request from '@/utils/request'

// 查询农产品价格比较表详细
export function getCompare_prices() {
  return request({
    url: '/compare_prices/compare_prices/getCompare_prices',
    method: 'post'
  })
}

export function getAllprices(form) {
  return request({
    url: '/compare_prices/compare_prices/getAllprices',
    method: 'post',
    data: form
  })
}