package com.ruoyi.apda.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.apda.domain.Bean;

public interface IBeanService extends IService<Bean> {
}
