package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.Meat;
import com.ruoyi.apda.mapper.MeatMapper;
import com.ruoyi.apda.service.IMeatService;
import org.springframework.stereotype.Service;

@Service
public class MeatServiceImpl extends ServiceImpl<MeatMapper, Meat> implements IMeatService {
}
