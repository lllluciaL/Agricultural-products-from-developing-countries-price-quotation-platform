package com.ruoyi.apda.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ruoyi.apda.domain.Meat;
import com.ruoyi.apda.service.IMeatService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 肉类信息Controller
 *
 * @author zyn
 * @date 2023-07-07
 */
@RestController
@RequestMapping("/meat/meat")
public class MeatController extends BaseController
{
    @Autowired
    private IMeatService meatService;

    /**
     * 查询肉类信息列表
     */
    @PreAuthorize("@ss.hasPermi('meat:meat:list')")
    @GetMapping("/list")
    public TableDataInfo list(Meat meat)
    {
        QueryWrapper<Meat> queryWrapper=new QueryWrapper<>();
        if(meat.getPricetype()!=null&&!"".equals(meat.getPricetype())){
            queryWrapper.like("pricetype",meat.getPricetype());
        }
        if(meat.getPriceunit()!=null&&!"".equals(meat.getPriceunit())){
            queryWrapper.eq("priceunit",meat.getPriceunit());
        }
        startPage();
        List<Meat> list = meatService.list(queryWrapper);
        return getDataTable(list);
    }

}
