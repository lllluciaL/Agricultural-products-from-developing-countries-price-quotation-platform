package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.Livestock;
import org.springframework.stereotype.Repository;

@Repository
public interface LivestockMapper extends BaseMapper<Livestock> {
}
