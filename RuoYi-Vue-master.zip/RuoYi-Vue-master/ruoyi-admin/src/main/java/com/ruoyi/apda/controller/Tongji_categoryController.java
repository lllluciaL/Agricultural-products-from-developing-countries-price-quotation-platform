package com.ruoyi.apda.controller;

import com.ruoyi.apda.form.Name;
import com.ruoyi.apda.service.Tongji_categoryService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/tongji_category/tongji_category")
@CrossOrigin
public class Tongji_categoryController extends BaseController {
    @Autowired
    private Tongji_categoryService tongji_categoryService;

    /**
     * 查询【请填写功能名称】列表
     */
    @PreAuthorize("@ss.hasPermi('tongji_category:tongji_category:getAllCategory')")
    @PostMapping ("/getAllCategory")
    public TableDataInfo getAllParities(@RequestBody Name name){
        System.out.println("Name:"+name.getName());
        List<Map<String,Object>> list=tongji_categoryService.ListByName(name);
        System.out.println(list);
        return getDataTable(list);


    }

    @PreAuthorize("@ss.hasPermi('tongji_category:tongji_category:getAllCountry')")
    @PostMapping ("/getAllCountry")
    public TableDataInfo getAllCountry(){
        return getDataTable(tongji_categoryService.getAllCountry());
    }
}
