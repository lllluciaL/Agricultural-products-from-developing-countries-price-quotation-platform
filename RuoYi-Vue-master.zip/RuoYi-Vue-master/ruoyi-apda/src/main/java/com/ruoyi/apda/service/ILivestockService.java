package com.ruoyi.apda.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.apda.domain.Livestock;

public interface ILivestockService extends IService<Livestock> {
}
