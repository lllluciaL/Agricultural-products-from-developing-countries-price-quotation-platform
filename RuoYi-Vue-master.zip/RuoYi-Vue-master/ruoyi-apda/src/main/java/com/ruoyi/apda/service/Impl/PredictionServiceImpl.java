package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.Prediction;
import com.ruoyi.apda.mapper.PredictionMapper;
import com.ruoyi.apda.service.IPredictionService;
import org.springframework.stereotype.Service;

@Service
public class PredictionServiceImpl extends ServiceImpl<PredictionMapper, Prediction> implements IPredictionService {
}
