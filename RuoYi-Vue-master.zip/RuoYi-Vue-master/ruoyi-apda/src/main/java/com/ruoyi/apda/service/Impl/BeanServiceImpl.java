package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.Bean;
import com.ruoyi.apda.mapper.BeanMapper;
import com.ruoyi.apda.service.IBeanService;
import org.springframework.stereotype.Service;

@Service
public class BeanServiceImpl extends ServiceImpl<BeanMapper, Bean> implements IBeanService {
}
