package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.MktTab;
import com.ruoyi.apda.form.Market;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface MktTabMapper extends BaseMapper<MktTab> {
    List<Map<String, Object>> getAllname();

    List<Map<String, Object>> ListByPrice(Market market);
}
