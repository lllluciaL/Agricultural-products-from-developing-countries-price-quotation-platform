package com.ruoyi.apda.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.apda.domain.FoodCountry;

public interface IFoodCountryService extends IService<FoodCountry> {
}
