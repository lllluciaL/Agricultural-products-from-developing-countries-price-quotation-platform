package com.ruoyi.apda.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.apda.domain.ComparePrices;

import java.util.List;
import java.util.Map;

public interface IComparePricesService extends IService<ComparePrices> {
    List<Map<String,Object>> getCompare_prices();


    List<Map<String, Object>> ListByPrice(com.ruoyi.apda.form.Price price);
}
