import request from '@/utils/request'

// 查询农产品价格比较表详细
export function getAllname() {
  return request({
    url: '/mkt_tab/mkt_tab/getAllname',
    method: 'post'
  })
}
export function getAllprices(form) {
  return request({
    url: '/mkt_tab/mkt_tab/getAllprices',
    method: 'post',
    data: form
  })
}