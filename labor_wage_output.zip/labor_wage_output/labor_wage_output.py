import pandas as pd

#读取初始文件
food_prices = pd.read_csv('file/food_prices.csv')

#读取汇率文件
parities = pd.read_csv('file/parities.csv')

#提取劳动力数据[国家名称，商品名称，单位，月，年，价格]
food_labor_1 = food_prices[['adm0_name','cm_name','um_name','mp_month','mp_year','mp_price']]
food_labor_2 = food_labor_1[food_labor_1['cm_name'].isin(['Wage (qualified labour)','Wage (non-qualified labour, non-agricultural)','Wage (non-qualified labour)'])]

#进行两个表的合并
merged_data = pd.merge(food_labor_2, parities[['adm0_name', 'parities']], on='adm0_name', how='left')

#进行汇率转换
merged_data['mp_price'] = merged_data['mp_price'] * merged_data['parities'].astype(float)

#进行单位转换
merged_data.loc[merged_data['um_name'] == 'Month', 'mp_price'] = merged_data.loc[merged_data['um_name'] == 'Month', 'mp_price'] / 30
merged_data.loc[merged_data['um_name'] == 'Month', 'um_name'] = 'Day'

#将日期合并
merged_data['year_month'] = merged_data['mp_year'].astype(str).str.cat(merged_data['mp_month'].astype(str), sep='|')

#删除年，月,汇率列
merged_data.drop(['mp_year'], axis = 1,inplace=True)
merged_data.drop(['mp_month'], axis = 1,inplace=True)
merged_data.drop(['parities'], axis = 1,inplace=True)
merged_data.drop(['um_name'], axis = 1,inplace=True)

#修改商品名称
#merged_data.loc[merged_data['cm_name'] == 'Wage (non-qualified labour, non-agricultural)','cmname'] = 'Wage (non-qualified labour non-agricultural)'
merged_data.loc[merged_data['cm_name'] == 'Wage (non-qualified labour, non-agricultural)', 'cm_name'] = 'Wage (non-qualified labour non-agricultural)'

#将数据输出为food_labor.csv
#无头
outputpath='file/food_labor(no head).csv'
merged_data.to_csv(outputpath,sep=',',index=True,header=False)
#有头
outputpath='file/food_labor.csv'
merged_data.to_csv(outputpath,sep=',',index=True,header=True)