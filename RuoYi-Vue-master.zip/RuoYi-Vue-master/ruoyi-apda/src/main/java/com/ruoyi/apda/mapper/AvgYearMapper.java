package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.AvgYear;
import org.springframework.stereotype.Repository;

@Repository
public interface AvgYearMapper extends BaseMapper<AvgYear> {
}
