package com.ruoyi.apda.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ComparePrices implements Serializable {
    private static final long serialVersionUID = 1L;
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 品牌编号 */
    @Excel(name = "国家名称")
    private String adm0Name;

    /** $column.columnComment */
    @Excel(name = "农产品名称")
    private String cmName;

    /** $column.columnComment */
    @Excel(name = "农产品单位价格")
    private Long price;

    /** $column.columnComment */
    @Excel(name = "农产品基本单位")
    private String unit;

    /** $column.columnComment */
    @Excel(name = "年份")
    private String dateYear;

    /** $column.columnComment */
    @Excel(name = "价格类型")
    private String priceType;
}
