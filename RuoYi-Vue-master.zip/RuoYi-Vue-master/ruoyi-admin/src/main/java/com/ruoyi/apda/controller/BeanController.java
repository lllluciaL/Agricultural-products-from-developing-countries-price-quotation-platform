package com.ruoyi.apda.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.apda.domain.Bean;
import com.ruoyi.apda.service.IBeanService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 豆类信息Controller
 *
 * @author ljy
 * @date 2023-07-07
 */
@RestController
@RequestMapping("/bean/bean")
public class BeanController extends BaseController
{
    @Autowired
    private IBeanService beanService;

    /**
     * 查询品牌管理列表
     */
    @PreAuthorize("@ss.hasPermi('bean:bean:list')")
    @GetMapping("/list")
    public TableDataInfo list(Bean bean)
    {
        startPage();
        //条件查询器QueryWrapper,该类是mybatis提供的类
        QueryWrapper<Bean> queryWrapper=new QueryWrapper<>();
        if(bean.getPricetype()!=null&&!"".equals(bean.getPricetype())){
            queryWrapper.like("pricetype",bean.getPricetype());
        }
        if(bean.getPriceunit()!=null&&!"".equals(bean.getPriceunit())){
            queryWrapper.eq("priceunit",bean.getPriceunit());
        }
        List<Bean> list = beanService.list(queryWrapper);
        return getDataTable(list);
    }

    //    查询所有品牌信息，初始化商品下拉列表
    @PreAuthorize("@ss.hasPermi('bean:bean:getAllBrands')")
    @GetMapping("/getAllBrands")
    public  TableDataInfo getAllBrands(){
        return getDataTable(beanService.list());
    }

    /**
     * 导出品牌管理列表
     */
    @PreAuthorize("@ss.hasPermi('bean:bean:export')")
    @Log(title = "豆类信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Bean bean)
    {
        List<Bean> list = beanService.list();
        ExcelUtil<Bean> util = new ExcelUtil<Bean>(Bean.class);
        util.exportExcel(response, list, "豆类管理数据");
    }

    /**
     * 获取品牌管理详细信息
     */
    @PreAuthorize("@ss.hasPermi('bean:bean:query')")
    @GetMapping(value = "/{bid}")
    public AjaxResult getInfo(@PathVariable("bid") Long bid)
    {
        return success(beanService.getById(bid));
    }


}
