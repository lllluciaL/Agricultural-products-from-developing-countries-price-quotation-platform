package com.ruoyi.apda.controller;

import java.util.List;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.apda.domain.Prediction;
import com.ruoyi.apda.service.IPredictionService;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 价格预测Controller
 *
 * @author zyn
 * @date 2023-07-11
 */
@RestController
@RequestMapping("/prediction/prediction")
public class PredictionController extends BaseController
{
    @Autowired
    private IPredictionService predictionService;

    /**
     * 查询价格预测列表
     */
    @PreAuthorize("@ss.hasPermi('prediction:prediction:list')")
    @GetMapping("/list")
    public TableDataInfo list(Prediction prediction)
    {
        QueryWrapper<Prediction> queryWrapper=new QueryWrapper<>();
        if(prediction.getAdm0Name()!=null&&!"".equals(prediction.getAdm0Name())){
            queryWrapper.like("adm0_name",prediction.getAdm0Name());
        }
        if(prediction.getAdm1Name()!=null&&!"".equals(prediction.getAdm1Name())){
            queryWrapper.like("adm1_name",prediction.getAdm1Name());
        }
        if(prediction.getCmName()!=null&&!"".equals(prediction.getCmName())){
            queryWrapper.like("cm_name",prediction.getCmName());
        }
        if(prediction.getPtName()!=null&&!"".equals(prediction.getPtName())){
            queryWrapper.like("pt_name",prediction.getPtName());
        }
        if(prediction.getUmName()!=null&&!"".equals(prediction.getUmName())){
            queryWrapper.like("um_name",prediction.getUmName());
        }


        startPage();
        List<Prediction> list = predictionService.list(queryWrapper);
        return getDataTable(list);
    }

}
