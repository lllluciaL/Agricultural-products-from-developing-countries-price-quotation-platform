package com.ruoyi.apda.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;

import java.io.Serializable;

public class Tongji_category  implements Serializable {
    @TableId(type = IdType.AUTO)
    private Long id;

    /** $column.columnComment */
    @Excel(name = "国家名称")
    private String name;

    /** $column.columnComment */
    @Excel(name = "粮食种类个数")
    private Long food;

    /** $column.columnComment */
    @Excel(name = "谷物种类个数")
    private Long grain;

    /** $column.columnComment */
    @Excel(name = "豆类种类个数")
    private Long legumes;

    /** $column.columnComment */
    @Excel(name = "水果种类个数")
    private Long fruit;

    /** $column.columnComment */
    @Excel(name = "蔬菜种类个数")
    private Long vegetable;

    /** $column.columnComment */
    @Excel(name = "肉种类个数")
    private Long meat;

    /** $column.columnComment */
    @Excel(name = "畜牧种类个数")
    private Long livestock;

    /** $column.columnComment */
    @Excel(name = "海鲜种类个数")
    private Long seafood;

    /** $column.columnComment */
    @Excel(name = "乳制品种类个数")
    private Long diary;

    /** $column.columnComment */
    @Excel(name = "糖种类个数")
    private Long sugars;

    /** $column.columnComment */
    @Excel(name = "脂肪种类个数")
    private Long fats;

    /** $column.columnComment */
    @Excel(name = "饮料种类个数")
    private Long beverages;

    /** $column.columnComment */
    @Excel(name = "蛋类种类个数")
    private Long eggs;

    /** $column.columnComment */
    @Excel(name = "调料种类个数")
    private Long seasoning;

    /** $column.columnComment */
    @Excel(name = "经济作物种类个数")
    private Long cash_Crop;
}
