package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.Foodprice;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface FoodpriceMapper extends BaseMapper<Foodprice> {
    List<Map<String, Object>> list_top10();
    List<Map<String, Object>> list_commoditysource();

    List<Map<String, Object>> list_country();
}
