/* <template>
  <!-- 卡片组件包含整体布局-->
  <el-card>
    <el-row :gutter="12">
      <el-col :span="6">
        <el-card>
          库存数量
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          总销售量
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          每日销售量
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card>
          总销售金额
        </el-card>
      </el-col>
    </el-row>
    <el-row>
      <el-col>
        <el-card>
          <div id="line" style="width: auto;height:400px;">
          </div>
        </el-card>
      </el-col>
      <el-col>
        <el-card>
          <div id="bar" style="width: auto;height:400px;">
          </div>
        </el-card>
      </el-col>
      <el-col>
        <el-card>
          <div id="pie" style="width: auto;height:400px;">
          </div>
        </el-card>
      </el-col>
    </el-row>
  </el-card>
</template>

<script>
  export default {
    data() {
      return {

      };
    },
    methods: {
      showBar() {
        let myEcharts = this.$echarts.init(document.getElementById("bar"));
        myEcharts.setOption({
          xAxis: {
            data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
          },
          yAxis: {},
          series: [{
            type: 'bar',
            data: [23, 24, 18, 25, 27, 28, 25]
          }]
        })
      },
      showLine() {
        let myEcharts = this.$echarts.init(document.getElementById("line"));
        myEcharts.setOption({
          xAxis: {
            type: 'category',
            data: ['A', 'B', 'C']
          },
          yAxis: {
            type: 'value'
          },
          series: [{
            data: [120, 200, 150],
            type: 'line'
          }]
        })
      },
      showPie() {
        let myEcharts = this.$echarts.init(document.getElementById("pie"));
        myEcharts.setOption({
          series: [{
            type: 'pie',
            data: [{
                value: 335,
                name: '直接访问'
              },
              {
                value: 234,
                name: '联盟广告'
              },
              {
                value: 1548,
                name: '搜索引擎'
              }
            ]
          }]
        })
      }
    },
    //created()挂载点不能渲染成功
    mounted() {
      this.showLine();
      this.showPie();
      this.showBar()
    }
  };
</script>

<style>
  .el-row {
    padding: 10px;
  }

  .el-col {
    padding: 4px;
  }
</style> */





<template>
  <div class="chart-container">
    <h1 class="chart-title">数据来源统计</h1>
    <div class="chart" ref="chart"></div>
  </div>
</template>

<script>
  import * as echarts from 'echarts'
  import 'echarts/map/js/world' // 引入世界地图数据
  import {
    getAllCountry
  } from "@/api/country/country";

  export default {
    data() {
      return {
        chartData: []
      }
    },
    mounted() {
      this.renderChart();
      this.getCountryList();
    },
    methods: {
      /**查询所有国家*/
      getCountryList() {
        getAllCountry().then(response => {
          console.info(response.rows)
          this.chartData = response.rows;
          // 调用renderChart方法
          this.renderChart();
        })
      },

      renderChart() {
        const chart = echarts.init(this.$refs.chart)

        // 数据处理
        const data = this.chartData.map(item => ({
          name: item.adm0Name,
          value: item.cmCount,
          adm1Count: item.adm1Count,
          cmCount: item.cmCount
        }))

        // 配置项
        const option = {
          tooltip: {
            trigger: 'item',
            formatter: function(params) {
              const {
                name,
                data
              } = params
              return `${name}<br/>城市个数: ${data.adm1Count}<br/>商品个数: ${data.cmCount}`
            }
          },
          visualMap: {
            min: 0,
            max: 30,
            inRange: {
              color: ['#d94e5d', '#eac736', '#50a3ba'].reverse()
            },
            textStyle: {
              color: '#fff'
            }
          },
          series: [{
              type: 'map',
              map: 'world',
              roam: true,
              formatter: function(params) {
                if (params.value > 0) { // 当数据大于0时才显示标签
                  return params.name;
                } else {
                  return '';
                }
              },
            data: data
          }
        ]
      }

      // 设置配置项并绘制图表
      chart.setOption(option)

      // 监听窗口大小变化，实现地图自适应
      window.addEventListener("resize", () => {
        chart.resize()
      })
    }
  }
  }
</script>

<style scoped>
  .chart-container {
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

  }

  .chart-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
  }

  .chart {
    flex: 1;
    width: 100%;
    height: 100%;
  }
</style>
