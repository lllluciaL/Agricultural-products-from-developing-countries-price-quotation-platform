package com.ruoyi.apda.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FoodCountry {
    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long aid;
    /** 国家名称 */
    @Excel(name = "国家名称")
    private String adm0Name;

    /** 城市个数 */
    @Excel(name = "城市个数")
    private Long adm1Count;

    /** 商品个数 */
    @Excel(name = "商品个数")
    private Long cmCount;
}
