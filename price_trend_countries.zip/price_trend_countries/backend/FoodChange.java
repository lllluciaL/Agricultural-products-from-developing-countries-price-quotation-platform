package com.ruoyi.apda.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FoodChange {
    private static final long serialVersionUID = 1L;
    @TableId(type = IdType.AUTO)
    /** id */
    private Long cid;

    /** 国家名称 */
    private String adm0Name;

    /** 商品名称 */
    private String cmName;

    /** 价格 */
    private Double priceUsd;

    /** 商品数量单位 */
    private String umName;

    /** 日期 */
    private String cmDate;

    /** 价格类型 */
    private String ptName;

}
