import request from '@/utils/request'

// 查询国家农产品分类统计详细
export function getAllCategory(data) {
  return request({
    url: '/tongji_category/tongji_category/getAllCategory',
    method: 'post',
    data:data
  })
}

export function getAllCountry() {
  return request({
    url: '/tongji_category/tongji_category/getAllCountry',
    method: 'post'
  })
}


