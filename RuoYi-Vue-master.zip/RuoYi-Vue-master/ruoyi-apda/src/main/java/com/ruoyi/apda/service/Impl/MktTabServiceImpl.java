package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.MktTab;
import com.ruoyi.apda.form.Market;
import com.ruoyi.apda.mapper.ComparePricesMapper;
import com.ruoyi.apda.mapper.MktTabMapper;
import com.ruoyi.apda.service.IMktTabService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class MktTabServiceImpl extends ServiceImpl<MktTabMapper, MktTab> implements IMktTabService {

    @Resource
    MktTabMapper mktTabMapper;

    @Override
    public List<Map<String, Object>> getAllname() {
        return mktTabMapper.getAllname();
    }

    @Override
    public List<Map<String, Object>> ListByPrice(Market market) {
        return mktTabMapper.ListByPrice(market);
    }
}
