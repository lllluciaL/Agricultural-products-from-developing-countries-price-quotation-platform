import request from '@/utils/request'

// 查询国家概览详细
export function getAllCountry() {
  return request({
    url: '/country/country/getAllCountry',
    method: 'get'
  })
}
