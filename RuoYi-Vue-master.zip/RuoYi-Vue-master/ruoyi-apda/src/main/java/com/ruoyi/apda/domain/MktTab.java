package com.ruoyi.apda.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MktTab implements Serializable {
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private String adm0Name;

    /** $column.columnComment */
    private String mktName;

    /** $column.columnComment */
    private String cmName;

    /** $column.columnComment */
    private String priceType;

    /** $column.columnComment */
    private String unit;

    /** $column.columnComment */
    private String dateYear;

    /** $column.columnComment */
    private Long price;

}
