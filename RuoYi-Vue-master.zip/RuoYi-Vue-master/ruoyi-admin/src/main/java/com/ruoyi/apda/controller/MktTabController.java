package com.ruoyi.apda.controller;


import com.ruoyi.apda.form.Market;
import com.ruoyi.apda.service.IMktTabService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/mkt_tab/mkt_tab")
public class MktTabController extends BaseController {
    @Autowired
    private IMktTabService mktTabService;

    @PreAuthorize("@ss.hasPermi('mkt_tab:mkt_tab:getAllname')")
    @PostMapping("/getAllname")
    public TableDataInfo getAllname(){
        return getDataTable(mktTabService.getAllname());
    }

    @PreAuthorize("@ss.hasPermi('mkt_tab:mkt_tab:getAllprices')")
    @PostMapping("/getAllprices")
    public AjaxResult getAllprices(@RequestBody Market market){
        System.out.println(market.getAdm0_name());
        List<Map<String,Object>> list=mktTabService.ListByPrice(market);
        System.out.println(list);
        return AjaxResult.success(list);
    }
}
