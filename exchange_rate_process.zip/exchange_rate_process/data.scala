package process

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.{col, concat, lit}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.{Row, SaveMode, SparkSession, functions}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.{SparkConf, SparkContext}

import java.io.{File, PrintWriter}

object data {
  def main(args: Array[String]): Unit = {
    // 创建SparkSession
    val spark = SparkSession.builder()
      .appName("parities")
      .master("local")
      .getOrCreate()

    // 读取汇率文件
    val exchangeRates = "D:/data/parities.csv"
    val csvExchangeRates = spark.read
      .format("csv")
      .option("header", "true") // 如果包含表头，则设置为true
      .option("inferSchema", "true") // 推断列的数据类型
      .load(exchangeRates)

    // 读取价格文件
    val prices = "D:/data/food_prices.csv"
    val csvPrices = spark.read
      .format("csv")
      .option("header", "true") // 如果包含表头，则设置为true
      .option("inferSchema", "true") // 推断列的数据类型
      .load(prices)

    //合并列函数
    def mergeColumns(df: DataFrame, column1: String, column2: String, mergedColumnName: String): DataFrame = {
      df.withColumn(mergedColumnName, concat(col(column1), lit("|"), col(column2)))
    }
    //删除列函数
    def removeColumns(df: DataFrame, columnsToRemove: Seq[String]): DataFrame = {
      val selectedColumns = df.columns.filterNot(columnsToRemove.contains)
      df.select(selectedColumns.head, selectedColumns.tail: _*)
    }

    //对价格文件进行数据清洗
    val newCsvPrices=csvPrices.filter(!csvPrices("cm_name").startsWith("Wage"))
      .filter(!(csvPrices("cm_name").startsWith("Exchange rate")))
      .filter(!(csvPrices("cm_name").startsWith("Transport")))
      .filter(!(csvPrices("cm_name").startsWith("Fuel")))
      .filter(!(csvPrices("cm_name").startsWith("Pulses")))
      .filter(!(csvPrices("cm_name").startsWith("Charcoal")))
      .filter(!(csvPrices("cm_name").startsWith("Dates")))

    //合并数据
    val mergedColumnName = "mp_date"
    val mergedDf = mergeColumns(newCsvPrices, "mp_year", "mp_month", mergedColumnName)


    val data = mergedDf.withColumn("category", lit(null))
    //print(data.count())  712481
    val data_filled=data.na.fill("0")
    //print(data_filled.count())  712481

    //对商品进行分类，并在数据集最后增加一列，标注分类
    val food=List("Millet","Millet (white)","Maize meal (white, roller)","Maize meal (white, breakfast)","Cassava meal","Bread (rye)",
      "Bread (common)","Rice (red nadu)","Bread (bakery)","Bread (shop)","Rice (regular, milled)","Maize meal (white, without bran) ",
      "Maize meal (white, with bran)","Rice (high quality)","Maize meal (white, first grade)","Rice (white, imported)","Bread (brown)",
      "Rice (imported, Egyptian)","Rice (glutinous, first quality)","Rice (glutinous, second quality)","Rice (glutinous, unmilled)",
      "Rice (ordinary, unmilled)","Bread (pita)","Bulgur", "Bread (khoboz)","Maize meal (local)","Rice (tchako)",
      "Rice (ordinary, first quality)","Rice (ordinary, second quality)", "Rice (basmati, broken)","Rice (long grain, imported)",
      "Rice (medium grain, imported)","Rice (small grain, imported)", "Rice (paddy, long grain, local)","Cassava (chikwangue)",
      "Maize meal","Rice (milled 80-20)","Rice (denikassia, imported)", "Rice (paddy)","Rice (imported, Tanzanian)",
      "Rice (high quality, local)", "Rice (low quality, local)","Rice (mixed, low quality)", "Rice (estaquilla)","Rice (long grain)",
      "Bread (wheat)","Rice (good quality)","Rice (carolina 2da)","Rice (medium grain)", "Noodles (short)","Rice (imported, Indian)",
      "Rice (local)","Cassava meal (gari)","Rice (imported)","Rice (coarse)", "Bread (high grade flour)","Bread (first grade flour)",
      "Rice (white)","Bread","Rice (low quality)","Rice","Pasta")
    val grain = List("Sorghum (food aid)","Buckwheat grits","Maize (imported)","Maize flour (imported)","Sorghum flour",
      "Wheat flour (locally processed)","Sorghum (brown)","Sorghum (taghalit)","Wheat flour (local)","Wheat flour (first grade)",
      "Wheat flour (high quality)","Maize flour (white)","Wheat flour (imported)","Tortilla (maize)","Fonio","Maize (local)",
      "Cashew","Cornstarch","Groundnuts (paste)","Beans (black)","Maize (yellow)","Sorghum (berbere)","Maize flour","Sorghum (red)",
      "Sorghum (white)","Sesame","Maize","Maize (white)","Sorghum","Wheat flour","Wheat")
    val legumes=List("Beans (kidney red)","Peas (yellow, split)","Beans (haricot)","Beans (kidney)","Beans (sugar) ",
      "Beans (green, fresh)","Peas (fresh)","Peas (dry)","Beans (mung)","Beans(mash)","Cowpeas (white)","Cowpeas (brown)",
      "Chickpeas (local)","Groundnuts (Mix)","Beans (butter)","Beans (magnum)","Groundnuts (large, shelled)",
      "Groundnuts (small, shelled)","Beans (catarino)","Peas (split, dry)","Beans (sugar-red)","Cowpeas","Beans (kidney white)",
      "Chickpeas","Lentils (urad)","Lentils (moong)","Beans (niebe, white)","Beans (dry)","Groundnuts (unshelled)",
      "Beans (fava, dry)","Beans (silk red)","Peanut","Groundnuts","Lentils (imported)","Beans (string)","Beans (red, fresh)",
      "Peas (green, dry)","Chickpeas (imported)","Beans (red)","Peas (yellow)","Soybeans","Groundnuts (shelled)","Beans (niebe)",
      "Beans","Beans (white)","Lentils","Lentils (masur)")
    val fruit=List("Bananas (medium size)","Avocados","Passion fruit","Tamarillos/tree tomatoes","Mangoes","Guava","Papaya",
      "Blackberry","Bananas","Apples","Apples (red)","Oranges (big size)")
    val vegetable=List("Onions (dry, local)","Potatoes (medium size)","Tomatoes (greenhouse)","Beetroots","Parsley",
      "Cassava leaves","Zucchini","Eggplants","Peppers (green)","Yam (Abuja)","Lettuce","Cucumbers","Chili (green)",
      "Chili (red)","Tomatoes (paste)","Yam","Plantains (apentu)","Potatoes (Irish)","Cassava","Yam (florido)",
      "Cassava (fresh)","Pumpkin","Broccoli","Spinach","Cassava (dry)","Cauliflower","Potatoes (unica)","Plantains",
      "Onions (red)","Onions (white)","Cassava (cossette)","Cassava flour","Sweet potatoes","Potatoes (black)",
      "Potatoes (Dutch)","Potatoes (Irish, imilla)","Cucumbers (greenhouse)","Potatoes","Tomatoes","Carrots","Onions","Cabbage")
    val meat=List("Meat (beef, canned)","Meat (beef, without bones)","Meat (mixed, sausage)","Meat (chicken, imported)","Meat (veal)",
      "Meat (goat)", "Poultry","Meat (beef, first quality)","Meat (beef, second quality)","Meat (buffalo, first quality)",
      "Meat (buffalo, second quality)","Meat (pork, first quality)","Meat (pork, second quality)","Meat (lamb)",
      "Meat (chicken, broiler)","Meat (mutton)","Meat (goat, with bones)", "Meat (chicken, frozen)","Meat (beef, minced)","Meat (chicken)",
      "Meat (pork, with fat)","Meat (beef, chops with bones)", "Meat (chicken, whole)","Meat (beef)","Meat (pork)","Meat (camel)")
    val livestock=List("Livestock (sheep, two-year-old male)","Livestock (cattle)","Livestock (pig)","Livestock (hen)",
      "Livestock (Goat)","Livestock (Sheep)","Livestock (Goat)","Livestock (Sheep)","Livestock (goat, medium-sized castrated male)",
      "Livestock (sheep, one-year-old alive female)","Livestock (sheep, medium-sized castrated male)")
    val seafood=List("Fish (sardine, canned)","Fish (frozen)","Fish (red snapper)","Fish (snake head)","Fish (catfish)","Fish (tilapia, farmed)",
      "Fish (tuna, canned)","Fish","Fish (bonga)","Fish (appolo)","Fish (smoked)","Fish (salted)","Fish (tilapia)",
      "Fish (dry)","Fish (fresh)","Fish (canned)")
    val dairy_pro=List("Cheese (goat)","Labaneh","Butter","Sour cream","Curd","Milk (powder, infant formula)","Yogurt",
      "Milk (cow, pasteurized)","Cheese (white, boiled)","Cheese (picon)","Milk (condensed)","Milk (powder)","Milk (pasteurized)",
      "Cheese","Milk","Cheese (dry)","Milk (camel)","Milk (non-pasteurized)")
    val sugars=List("Sugar (brown, imported)","Sugar (brown, local)","Sugar (jaggery/gur)","Sugar (white)","Sugar",
      "Sugar (brown)","Sugar (brown, loaf)")
    val fats=List("Oil (mixed)","Ghee (natural)","Oil (maize)","Fat (salo)","Ghee (artificial)","Oil (cooking)",
      "Oil (mixed, imported)","Oil (vegetable, local)","Oil (cotton)","Oil (olive)","Ghee (vanaspati)","Oil (mustard)",
      "Oil (soybean)","Oil (vegetable, imported)","Oil","Oil (vegetable)","Oil (palm)","Oil (groundnut)","Oil (sunflower)")
    val beverages=List("Water (drinking)","Cocoa (powder, not sweetened)","Tea (green)","Tea (black)","Tea","Tea (sahm)",
      "Cocoa","Coffee","Coffee (instant)")
    val eggs=List("Eggs","Eggs (white, AA)","Eggs (imported)")
    val seasoning=List("Gari (yellow)","Gari (white)","Salt","Gari","Salt (iodised)","Garlic (small)","Garlic")
    val cash_crop=List("Cotton")


    val result0=data_filled.withColumn("category", functions
      .when(functions.col("cm_name").isin(food:_*),"food")
      .when(functions.col("cm_name").isin(grain:_*),"grain")
      .when(functions.col("cm_name").isin(legumes:_*),"legumes")
      .when(functions.col("cm_name").isin(fruit:_*),"fruit")
      .when(functions.col("cm_name").isin(vegetable:_*),"vegetable")
      .when(functions.col("cm_name").isin(meat:_*),"meat")
      .when(functions.col("cm_name").isin(livestock:_*),"livestock")
      .when(functions.col("cm_name").isin(seafood:_*),"seafood")
      .when(functions.col("cm_name").isin(dairy_pro:_*),"dairy_pro")
      .when(functions.col("cm_name").isin(sugars:_*),"sugars")
      .when(functions.col("cm_name").isin(fats:_*),"fats")
      .when(functions.col("cm_name").isin(beverages:_*),"beverages")
      .when(functions.col("cm_name").isin(eggs:_*),"eggs")
      .when(functions.col("cm_name").isin(seasoning:_*),"seasoning")
      .when(functions.col("cm_name").isin(cash_crop:_*),"cash_crop")
    )

    val replaceCommaWithSpace = udf((cm_name: String) => cm_name.replace(",", " "))
    val result1=result0.withColumn("cm_name",replaceCommaWithSpace(col("cm_name")))


    //将价格数据与汇率数据进行连接
    val unifiedPrices = result1.join(csvExchangeRates, Seq("adm0_name"), "left")

    // 定义转换函数
    val convertCurrency = udf((price: Double, exchangeRate: Double) => price * exchangeRate)

    // 添加新列，存储美元价格
    val unifiedPricesWithUSD = unifiedPrices.withColumn("price_usd", convertCurrency(col("mp_price"), col("parities")))

    //删除原始数据
    val columnsToRemove = Seq("mp_year", "mp_month","cur_name","cur_id")
    val modifiedDf = removeColumns(unifiedPricesWithUSD, columnsToRemove)
    // 输出结果
    //modifiedDf.show()
    println(modifiedDf.count())
    val output="["+modifiedDf.toJSON.collect().mkString(",")+"]"
    val writer = new PrintWriter(new File("D:/data/food_clear.json"))
    writer.write(output)
    writer.close()




  }
}
