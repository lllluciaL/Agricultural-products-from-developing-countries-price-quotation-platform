package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.FoodLabor;
import org.springframework.stereotype.Repository;

@Repository
public interface FoodLaborMapper extends BaseMapper<FoodLabor> {
}
