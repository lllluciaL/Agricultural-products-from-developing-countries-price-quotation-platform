package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.FoodChange;
import org.springframework.stereotype.Repository;

@Repository
public interface FoodChangeMapper extends BaseMapper<FoodChange> {
}
