package com.ruoyi.apda.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.apda.domain.Foodprice;

import java.util.List;
import java.util.Map;

public interface IFoodpriceService extends IService<Foodprice> {
    List<Map<String, Object>> list_top10();
    List<Map<String, Object>> list_country();
    List<Map<String, Object>> list_commoditysource();
}
