import request from '@/utils/request'

// 查询牲畜信息列表
export function listLivestock(query) {
  return request({
    url: '/livestock/livestock/list',
    method: 'get',
    params: query
  })
}


