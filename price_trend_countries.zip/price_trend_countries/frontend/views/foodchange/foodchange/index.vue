<template>
  <div class="app-container">
    <h1>{{ title }}</h1>
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="国家名称" prop="adm0Name">
        <el-select v-model="queryParams.adm0Name" filterable placeholder="请选择国家名称" clearable @change="handleAdm0NameChange">
          <el-option v-for="(item, index) in adm0NameOptions" :key="index" :label="item" :value="item"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="商品名称" prop="cmName">
        <el-select v-model="queryParams.cmName" filterable placeholder="请先选择国家再选择商品" clearable @change="handleCmNameChange">
          <el-option v-for="(item, index) in cmNameOptions" :key="index" :label="item" :value="item"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <div ref="chart" style="width: 100%; height: 500px"></div>

  </div>
</template>

<script>
  import {
    listFoodchange,
    getFoodchange
  } from "@/api/foodchange/foodchange";
  import echarts from 'echarts'; // 导入echarts库

  export default {
    name: "Foodchange",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 显示搜索条件
        showSearch: true,
        // 总条数
        total: 0,
        // 价格变化趋势表格数据
        foodchangeList: [],
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,

        adm0NameOptions: [],

        cmNameOptions: [],
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 69002,
          adm0Name: null,
          cmName: null,
        },
        // 表单参数
        form: {},
        // 表单校验
        rules: {}
      };
    },
    created() {
      this.title = `价格变化趋势`;
      this.getData();
    },
    methods: {
      // 处理国家下拉框选择变化事件
          handleAdm0NameChange() {
            // 根据选中的国家名称过滤对应的商品名称
            const filteredCmNames = this.foodchangeList
              .filter(item => item.adm0Name === this.queryParams.adm0Name)
              .map(item => item.cmName);
            // 去除重复的商品名称
            const uniqueCmNames = [...new Set(filteredCmNames)];

            this.cmNameOptions = uniqueCmNames; // 将去重后的商品名称赋值给下拉列表选项
          },
          // 处理商品下拉框选择变化事件
              handleCmNameChange() {
                // 根据选中的商品名称过滤对应的国家名称
                const filteredAdm0Names = this.foodchangeList
                  .filter(item => item.cmName === this.queryParams.cmName)
                  .map(item => item.adm0Name);
                // 去除重复的国家名称
                const uniqueAdm0Names = [...new Set(filteredAdm0Names)];

                this.Adm0NameOptions = uniqueAdm0Names; // 将去重后的国家名称赋值给下拉列表选项
              },

      /** 获取数据列表 */
      async getData() {
        this.loading = true;
        try {
          const response = await listFoodchange(this.queryParams);
          this.foodchangeList = response.rows;
          this.total = response.total;
          this.loading = false;

          this.adm0NameOptions = [...new Set(response.rows.map(item => item.adm0Name))];
          this.cmNameOptions = [...new Set(response.rows.map(item => item.cmName))];

          this.renderChart(); // 在获取数据后渲染折线图
        } catch (error) {
          // 处理错误
          console.error(error);
          this.loading = false;
        }
      },

      /** 查询价格变化趋势列表 */
      async getList() {
        this.loading = true;
        try {
          const response = await listFoodchange(this.queryParams);
          if (!this.queryParams.adm0Name || !this.queryParams.cmName) {
                this.title = "价格变化趋势";
              } else {
                this.title = `${this.queryParams.adm0Name}的${this.queryParams.cmName}价格变化趋势`;
              }
          this.foodchangeList = response.rows;
          this.total = response.total;
          this.loading = false;

          this.adm0NameOptions = [...new Set(response.rows.map(item => item.adm0Name))];
          this.cmNameOptions = [...new Set(response.rows.map(item => item.cmName))];

          this.renderChart(); // 在获取数据后渲染折线图
        } catch (error) {
          // 处理错误
          console.error(error);
          this.loading = false;
        }
      },

      // 表单重置
      reset() {
        this.form = {
          cid: null,
          adm0Name: null,
          cmName: null,
          priceUsd: null,
          umName: null,
          cmDate: null,
          ptName: null
        };
        this.resetForm("form");
      },
      /** 搜索按钮操作 */
      handleQuery() {
        this.queryParams.pageNum = 1;
        this.getList();
      },
      /** 重置按钮操作 */
      resetQuery() {
        this.resetForm("queryForm");
        this.handleQuery();
      },
      renderChart() {
        const chartData = {};
        const legendData = [];
        const xAxisData = [];
        const seriesData = [];

        this.foodchangeList.forEach((item) => {
          if (!chartData[item.ptName]) {
            chartData[item.ptName] = {};
          }
          if (!chartData[item.ptName][item.cmDate]) {
            chartData[item.ptName][item.cmDate] = {};
          }
          if (!chartData[item.ptName][item.cmDate].adm0Name) {
            chartData[item.ptName][item.cmDate].adm0Name = item.adm0Name;
          }
          if (!chartData[item.ptName][item.cmDate].cmName) {
            chartData[item.ptName][item.cmDate].cmName = item.cmName;
          }
          if (!chartData[item.ptName][item.cmDate].ptName) {
            chartData[item.ptName][item.cmDate].ptName = item.ptName;
          }
          if (!chartData[item.ptName][item.cmDate].umName) {
              chartData[item.ptName][item.cmDate].umName = item.umName;
            }

          chartData[item.ptName][item.cmDate].priceUsd = item.priceUsd;

          if (!legendData.includes(item.ptName)) {
            legendData.push(item.ptName);
          }
          if (!xAxisData.includes(item.cmDate)) {
            xAxisData.push(item.cmDate);
          }
        });

        for (const ptName of legendData) {
          const seriesItem = {
            name: ptName,
            type: "line",
            data: [],
            label: {
                  show: false,
                  formatter: function(params) {
                    const priceUmName = chartData[params.seriesName][params.name]?.umName || ''; // 获取对应的价格单位
                    return params.value + ' ' + priceUmName;
                  },
                },
          };
          for (const cmDate of xAxisData) {
            seriesItem.data.push(chartData[ptName][cmDate]?.priceUsd ?? null);
          }
          seriesData.push(seriesItem);
        }

        const chart = echarts.init(this.$refs.chart);
        const option = {
          tooltip: {
            trigger: "axis",
            formatter: function(params) {
                  let tooltip = '';
                  const date = params[0]?.name || ''; // 获取日期
                      tooltip += 'Date: ' + date + '<br/>'; // 在 tooltip 中显示日期
                  for (let i = 0; i < params.length; i++) {
                    const series = params[i];
                    const priceUmName = chartData[series.seriesName][series.name]?.umName || ''; // 获取对应的价格单位
                    tooltip += series.marker + ' ' + series.seriesName + ': ' + series.value + '/' + priceUmName + '<br/>';
                  }
                  return tooltip;
                },
          },
          legend: {
            data: legendData,
          },
          xAxis: {
            type: "category",
            data: xAxisData,
            axisLabel: {
              interval: 12, // 显示横轴数据
              formatter: function(value, index) {
                    // 格式化日期，仅显示年月
                    return value.slice(0, 7);
                  }
            },
            name: '日期', // 添加横坐标的图例
          },
          yAxis: {
            type: "value",
            name: '价格/美元', // 添加纵坐标的图例
          },
          series: seriesData,
        };
        chart.setOption(option,true);
      },
    }
  };
</script>
<style>
  .app-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
  }
</style>
