import request from '@/utils/request'

// 查询米类信息列表
export function listRice(query) {
  return request({
    url: '/rice/rice/list',
    method: 'get',
    params: query
  })
}