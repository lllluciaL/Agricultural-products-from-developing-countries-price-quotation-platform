package com.ruoyi.apda.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.FoodChange;
import com.ruoyi.apda.mapper.FoodChangeMapper;
import com.ruoyi.apda.service.IFoodChangeService;
import org.springframework.stereotype.Service;

@Service
public class FoodChangeServiceImpl extends ServiceImpl<FoodChangeMapper, FoodChange> implements IFoodChangeService {
}
