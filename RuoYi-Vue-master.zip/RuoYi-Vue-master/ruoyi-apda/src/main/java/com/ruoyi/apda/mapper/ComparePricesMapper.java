package com.ruoyi.apda.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.apda.domain.ComparePrices;
import com.ruoyi.apda.form.Price;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface ComparePricesMapper extends BaseMapper<ComparePrices> {

    List<Map<String, Object>> getCompare_prices();

    List<Map<String, Object>> ListByPrice(Price price);
}
