package com.ruoyi.apda.form;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Market {
    private String adm0_name;
    private String cm_name;
    private String unit;
    private String price_type;
}
