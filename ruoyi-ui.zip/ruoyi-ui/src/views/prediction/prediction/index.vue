<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px">
      <el-row>
        <el-col :span="8">
          <el-form-item label="国家名称" prop="adm0Name">
            <el-input v-model="queryParams.adm0Name" placeholder="请输入国家名称" clearable
              @keyup.enter.native="handleQuery" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="城市名称" prop="adm1Name">
            <el-input v-model="queryParams.adm1Name" placeholder="请输入城市名称" clearable
              @keyup.enter.native="handleQuery" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="商品名称" prop="cmName">
            <el-input v-model="queryParams.cmName" placeholder="请输入商品名称" clearable @keyup.enter.native="handleQuery" />
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="8">
          <el-form-item label="价格类型" prop="ptName">
            <el-input v-model="queryParams.ptName" placeholder="请输入价格类型" clearable @keyup.enter.native="handleQuery" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item label="商品单位" prop="umName">
            <el-input v-model="queryParams.umName" placeholder="请输入商品单位" clearable @keyup.enter.native="handleQuery" />
          </el-form-item>
        </el-col>
        <el-col :span="8">
          <el-form-item>
            <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
            <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <el-table v-loading="loading" :data="predictionList" @selection-change="handleSelectionChange">
      <el-table-column label="国家名称" align="center" prop="adm0Name" />
      <el-table-column label="城市名称" align="center" prop="adm1Name" />
      <el-table-column label="商品名称" align="center" prop="cmName" />
      <el-table-column label="价格类型" align="center" prop="ptName" />
      <el-table-column label="商品数量单位" align="center" prop="umName" />
      <el-table-column label="2015年价格" align="center" prop="price2015" />
      <el-table-column label="2016年价格" align="center" prop="price2016" />
      <el-table-column label="2017年价格" align="center" prop="price2017" />
      <el-table-column label="预测价格" align="center" prop="pricePredict" />
    </el-table>

    <pagination v-show="total>0" :total="total" :page.sync="queryParams.pageNum" :limit.sync="queryParams.pageSize"
      @pagination="getList" />
    <div class="chart-container" style="margin-top: 100px;">
      <div id="chart" style="width: 800px; height: 600px;"></div>
    </div>
  </div>

</template>

<script>
  import {
    listPrediction
  } from "@/api/prediction/prediction";
  import echarts from 'echarts'; // 导入echarts库


  export default {
    name: "Prediction",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 显示搜索条件
        showSearch: true,
        // 总条数
        total: 0,
        // 价格预测表格数据
        predictionList: [],
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 10,
          adm0Name: null,
          adm1Name: null,
          cmName: null,
          ptName: null,
          umName: null,
          pricePredict: null
        },
        // 表单参数
        form: {},
        // 表单校验
        rules: {}
      };
    },
    created() {
      this.getList();
    },
    mounted() {
        this.createChart()
      },
    methods: {
      /** 查询价格预测列表 */
      getList() {
        this.loading = true;
        listPrediction(this.queryParams).then(response => {
          this.predictionList = response.rows;
          this.total = response.total;
          this.loading = false;
        });
      },
      // 表单重置
      reset() {
        this.form = {
          pid: null,
          adm0Name: null,
          adm1Name: null,
          cmName: null,
          ptName: null,
          umName: null,
          price2015: null,
          price2016: null,
          price2017: null,
          pricePredict: null
        };
        this.resetForm("form");
      },
      /** 搜索按钮操作 */
      handleQuery() {
        this.queryParams.pageNum = 1;
        this.getList();
      },
      /** 重置按钮操作 */
      resetQuery() {
        this.resetForm("queryForm");
        this.handleQuery();
      },
      // 多选框选中数据
      handleSelectionChange(selection) {
        this.ids = selection.map(item => item.pid)
        this.single = selection.length !== 1
        this.multiple = !selection.length
      },
    createChart() {
      // 提供的数据
      const data = [{
          "rf_rmse": 122.88570941480307,
          "dt_rmse": 116.71271964112321,
          "lr_rmse": 387.64626486727315
        },
        {
          "rf_rmse": 78.22894727534722,
          "dt_rmse": 134.12293793340763,
          "lr_rmse": 382.99259255319055
        },
        {
          "rf_rmse": 128.6834667199672,
          "dt_rmse": 134.38209790277438,
          "lr_rmse": 405.0675760131155
        },
        {
          "rf_rmse": 89.77340035578973,
          "dt_rmse": 142.71076540183114,
          "lr_rmse": 394.20637632267244
        },
        {
          "rf_rmse": 168.0840336845144,
          "dt_rmse": 148.2385548788097,
          "lr_rmse": 426.3853861354412
        },
        {
          "rf_rmse": 100.01006896538668,
          "dt_rmse": 86.07306602932745,
          "lr_rmse": 354.3597487480004
        },
        {
          "rf_rmse": 149.95414312296248,
          "dt_rmse": 148.03072657916715,
          "lr_rmse": 421.19748016800764
        },
        {
          "rf_rmse": 166.49042304066217,
          "dt_rmse": 141.06220891124872,
          "lr_rmse": 456.932851158302
        },
        {
          "rf_rmse": 106.36217034934167,
          "dt_rmse": 94.8468902587042,
          "lr_rmse": 391.2860095057576
        },
        {
          "rf_rmse": 123.51183782093216,
          "dt_rmse": 113.27716109669532,
          "lr_rmse": 417.2719758344127
        }
      ]

      // 将数据按列分组
      const rf_rmse = data.map(item => item.rf_rmse)
      const dt_rmse = data.map(item => item.dt_rmse)
      const lr_rmse = data.map(item => item.lr_rmse)

      // 创建图表实例
      const chart = echarts.init(document.getElementById('chart'))

      // 设置图表配置项
      const option = {
        title:{
          text:'RMSE比较图表',
          right:'75%',
          textStyle:{
            fonsSize:20
          }
        },
        legend:{
          data:['rf_rmse','dt_rmse','lr_rmse']
        },
        xAxis: {
          type: 'category',
          data: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
          name: "迭代次数"
        },
        yAxis: {
          type: 'value',
          name: "rmse"
        },
        series: [{
            name: 'rf_rmse',
            type: 'line',
            data: rf_rmse
          },
          {
            name: 'dt_rmse',
            type: 'line',
            data: dt_rmse
          },
          {
            name: 'lr_rmse',
            type: 'line',
            data: lr_rmse
          }
        ]
      }

      const chartContainer = document.getElementById('chart');
      chartContainer.style.width = '800px'; // 设置容器宽度
      chartContainer.style.height = '600px'; // 设置容器高度
      chartContainer.style.margin = '0 auto'; // 设置容器水平居中

      // 渲染图表
      chart.setOption(option)
    }
    }
  };
</script>

<style>
  #chart {
    margin-top: 100px;
  }
</style>
