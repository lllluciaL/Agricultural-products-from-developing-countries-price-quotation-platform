package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.Rice;
import com.ruoyi.apda.mapper.RiceMapper;
import com.ruoyi.apda.service.IRiceService;
import org.springframework.stereotype.Service;

@Service
public class RiceServiceImpl extends ServiceImpl<RiceMapper, Rice> implements IRiceService {
}
