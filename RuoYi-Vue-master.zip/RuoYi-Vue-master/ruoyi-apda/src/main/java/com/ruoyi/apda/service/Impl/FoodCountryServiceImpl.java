package com.ruoyi.apda.service.Impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.apda.domain.FoodCountry;
import com.ruoyi.apda.mapper.FoodCountryMapper;
import com.ruoyi.apda.service.IFoodCountryService;
import org.springframework.stereotype.Service;

@Service
public class FoodCountryServiceImpl extends ServiceImpl<FoodCountryMapper, FoodCountry> implements IFoodCountryService{
}
