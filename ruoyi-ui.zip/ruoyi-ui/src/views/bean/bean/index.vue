<template>
  <div class="app-container">
    <h1 class="chart-title">豆类信息</h1>
    <el-form :model="queryParams" ref="queryForm" size="small" :inline="true" v-show="showSearch" label-width="68px"
      class="search-container">
      <el-form-item label="单位" prop="priceunit">
        <el-select v-model="queryParams.priceunit" placeholder="请选择单位" clearable @change="handlepriceunitChange">
          <el-option v-for="(item, index) in queryParams.priceunitOptions" :key="index" :label="item"
            :value="item"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="价格类型" prop="pricetype">
        <el-select v-model="queryParams.pricetype" placeholder="请选择价格类型" clearable @change="handlepricetypeChange">
          <el-option v-for="(item, index) in queryParams.pricetypeOptions" :key="index" :label="item"
            :value="item"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row>
      <el-col :span="24">
        <div ref="chart" style="height: 600px; overflow: auto;"></div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import {
    listBean
  } from "@/api/bean/bean";
  import echarts from "echarts";

  export default {
    name: "Bean",
    data() {
      return {
        // 遮罩层
        loading: true,
        // 选中数组
        ids: [],
        // 非单个禁用
        single: true,
        // 非多个禁用
        multiple: true,
        // 显示搜索条件
        showSearch: true,
        // 总条数
        total: 0,
        // 肉类信息表格数据
        beanList: [],
        // 弹出层标题
        title: "",
        // 是否显示弹出层
        open: false,
        // 查询参数
        queryParams: {
          pageNum: 1,
          pageSize: 40,
          priceunit: '',
          pricetype: '',
          priceunitOptions: [], //单位下拉列表选项
          pricetypeOptions: [] //价格类型下拉列表选项
        },
        // 表单参数
        form: {},
        // 表单校验
        rules: {},
        // 图表实例
        chart: null,
      };
    },
    created() {

      this.getList();
    },
    mounted() {
      // 初始化图表实例
      this.chart = echarts.init(this.$refs.chart);

      // 调用渲染图表方法
      this.renderChart();
    },
    methods: {
      // 处理单位下拉框选择变化事件
      handlepriceunitChange() {
        // 根据选中的单位过滤对应的商品名称
        const filteredpricetype = this.beanList
          .filter(item => item.priceunit === this.queryParams.priceunit)
          .map(item => item.pricetype);
        // 去除重复的价格类型
        const uniquepricetype = [...new Set(filteredpricetype)];

        this.queryParams.pricetypeOptions = uniquepricetype; // 将去重后的价格类型赋值给下拉列表选项
      },
      // 处理价格类型下拉框选择变化事件
      handlepricetypeChange() {
        // 根据选中的价格类型过滤对应的商品名称
        const filteredpriceunit = this.beanList
          .filter(item => item.pricetype === this.queryParams.pricetype)
          .map(item => item.priceunit);
        // 去除重复的单位
        const uniquepriceunit = [...new Set(filteredpriceunit)];

        this.queryParams.priceunitOptions = uniquepriceunit; // 将去重后的单位赋值给下拉列表选项
      },
      /** 获取数据列表 */
      getSelect() {
        this.loading = true;
        listBean(this.queryParams).then(response => {

          // 去除重复的单位
          const uniquepriceunit = [...new Set(response.rows.map(item => item.priceunit))];
          // 去除重复的价格类型
          const uniquepricetype = [...new Set(response.rows.map(item => item.pricetype))];

          this.beanList = response.rows;
          this.total = response.total;
          this.loading = false;

          this.queryParams.priceunitOptions = uniquepriceunit; // 将去重后的单位赋值给下拉列表选项
          this.queryParams.pricetypeOptions = uniquepricetype; // 将去重后的价格类型赋值给下拉列表选项

        });
      },
      /** 查询肉类信息列表 */
      getList() {
        this.loading = true;
        listBean(this.queryParams).then(response => {
          // 去除重复的单位
          const uniquepriceunit = [...new Set(response.rows.map(item => item.priceunit))];
          // 去除重复的价格类型
          const uniquepricetype = [...new Set(response.rows.map(item => item.pricetype))];

          this.beanList = response.rows;
          this.total = response.total;
          this.loading = false;
          this.renderChart(); // 在获取到数据后渲染图表

          this.queryParams.priceunitOptions = uniquepriceunit; // 将去重后的单位赋值给下拉列表选项
          this.queryParams.pricetypeOptions = uniquepricetype; // 将去重后的价格类型赋值给下拉列表选项

        });
      },
      // 表单重置
      reset() {
        this.form = {
          mid: null,
          mname: null,
          countrysum: null,
          price: null,
          priceunit: null,
          pricetype: null
        };
        this.resetForm("form");
      },
      /** 搜索按钮操作 */
      handleQuery() {
        this.queryParams.pageNum = 1;
        this.getList();
        this.getSelect();
        //this.renderChart();
      },
      /** 重置按钮操作 */
      resetQuery() {
        this.resetForm("queryForm");
        this.handleQuery();
      },
      // 多选框选中数据
      handleSelectionChange(selection) {
        this.ids = selection.map(item => item.mid)
        this.single = selection.length !== 1
        this.multiple = !selection.length
      },
      // 渲染图表
      renderChart() {
        // 清空图表
        this.chart.clear();
        console.info(this.beanList);
        // 获取数据
        listBean(this.queryParams).then(response => {
          // 处理数据
          const xAxisData = response.rows.map(item => item.bname);
          const lineData = response.rows.map(item => item.price);
          const barData = response.rows.map(item => item.countrysum);

          // 配置项
          const option = {
            tooltip: {
              trigger: 'axis',
              axisPointer: {
                type: 'line'
              }

            },
            grid: {
              top: 60,
              bottom: 120,
              left: 60,
              right: 60
            },
            legend: {
              data: ['价格', '国家个数']
            },
            xAxis: {
              type: 'category',
              data: xAxisData,
              axisLabel: {
                interval: 0,
                rotate: 45
              } // 显示横轴数据
            },
            yAxis: [{
                type: 'value',
                name: '价格/美元',
                position: 'left'
              },
              {
                type: 'value',
                name: '国家个数',
                position: 'right'
              }
            ],
            series: [{
                name: '价格',
                type: 'line',
                yAxisIndex: 0,
                data: lineData
              },
              {
                name: '国家个数',
                type: 'bar',
                yAxisIndex: 1,
                data: barData
              }
            ]
          };

          // 渲染图表
          this.chart.setOption(option);
        });
      },
    },
  };
</script>
<style>
  .search-container {
    display: flex;
    justify-content: center;
  }

  .chart-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
    text-align: center;
  }
</style>
